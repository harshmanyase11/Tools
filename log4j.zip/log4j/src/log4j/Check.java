package log4j;

import java.awt.AWTException;
import java.io.File;
import java.io.IOException;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.apache.log4j.PatternLayout;
import org.apache.log4j.varia.LevelRangeFilter;

import config.ProbeConfig;
import sp_Logger.DataBaseAppender;
import sp_Logger.DefaultAppender;
import sp_Logger.Log_ConsoleAppender;
import sp_Logger.RollingFileAppender;

public class Check {

	static Logger logger = Logger.getLogger(Check.class);
	private File tmp;
	String fileName = "Probe";
	public String baseFileName;
	String Pattern = "%d - %5p - [%t] - (%F:%L) - %m%n";

	public void load_DB_Info_From_Xml() {
		ProbeConfig dbProperty = new ProbeConfig("DBconfig.properties");
		dbProperty.getPropertyValue("dbDriver");
		dbProperty.getPropertyValue("dbUrl");
		dbProperty.getPropertyValue("dbUserName");
		dbProperty.getPropertyValue("dbPassWord");
	}

	public DataBaseAppender DBappender() {
		String DBconversationPattern = "%d{YYYY-MM-dd HH:mm:ss} [%t] %p %c - %m%n";
		String Url = "jdbc:oracle:thin:@localhost:1521:xe";
		String password = "manager";
		String userName = "system";
		String driver = "oracle.jdbc.OracleDriver";

		DataBaseAppender DB = new DataBaseAppender();		
		DB.setDbUserName(userName);
		DB.setDbDriver(driver);
		DB.setDbconversationPattern(DBconversationPattern);
		DB.setDbUrl(Url);
		DB.setDbPassword(password);	
		LevelRangeFilter filter = new LevelRangeFilter();
		filter.setLevelMax(Level.ERROR);
		filter.setLevelMin(Level.DEBUG);
		DB.addFilter(filter);
		DB.setSql("INSERT INTO Application_Log_Table(LOGDATE,LOGCLASS,LOGLEVEL,LOGMESSAGE) VALUES(to_timestamp('%d{YYYY-MM-dd HH.mm.ss.SS}','YYYY/MM/DD HH24:MI:SS.FF'),'%F:%L','%p','%m')");
		DB.activateOptions();
		return DB;
	}
	public Log_ConsoleAppender console()
	{
		Log_ConsoleAppender con=new Log_ConsoleAppender();
		con.setName("console");
		con.setTarget("System.out");
		con.setLayout(new PatternLayout(" %d{yyyy-MM-dd HH:mm:ss.SS} - %5p - [%t] - (%F:%L) - %m%n"));
		con.activateOptions();
		return con;
	}

	public RollingFileAppender myappender() throws IOException {

		RollingFileAppender rollInstance = new RollingFileAppender();
		rollInstance.setName("file App");
		rollInstance.setMaxFileSize("1MB");
		rollInstance.setLayout(new PatternLayout("%d{yyyy-MM-dd HH:mm:ss} - %5p - [%t] - (%F:%L) - %m%n"));
		rollInstance.setFile("Probe");
		rollInstance.setMaxBackupIndex(1);
		/*LevelRangeFilter filter = new LevelRangeFilter();
		filter.setLevelMax(Level.INFO);
		filter.setLevelMin(Level.DEBUG);
		rollInstance.addFilter(filter);*/
		rollInstance.activateOperation();
		return rollInstance;
	}

	public Check() {

		 //logger=new DefaultAppender().getLogger(true, true);
		 logger.addAppender(DBappender());
		 logger.addAppender(console());
		
		 try { logger.addAppender(myappender()); } catch (IOException e) {
		 e.printStackTrace(); }
		 
		//logger.addAppender(new Log_ConsoleAppender().getBasicConsolAppender());
	}

	public static void main(String[] args) throws IOException, AWTException {
		Check ck = new Check();

		int i = 0;
		//logger.setLevel(Level.INFO);
		while (i < 1) {
			i++;
			logger.info("appender");
			logger.debug("Program is debuging");
			logger.error("Error log");
			logger.fatal("Fetal message ");
			logger.warn("Warn message");
		}
	}

}

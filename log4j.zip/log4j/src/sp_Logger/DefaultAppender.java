package sp_Logger;

import java.io.IOException;
import java.nio.file.DirectoryStream.Filter;

import org.apache.log4j.ConsoleAppender;
import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.apache.log4j.PatternLayout;
import org.apache.log4j.jdbc.JDBCAppender;
import org.apache.log4j.varia.LevelRangeFilter;

public class DefaultAppender {

	private String fileName = "Log_File";
	private String maxFileSize = "10MB";
	private int maxFileBackup = 0;
	private String dateFormate = "yyyy-MM-dd HH.mm.ss";
	private String ConvertionPattern = "%d - %5p - [%t] - (%F:%L) - %m%n";
	private final Logger log = Logger.getLogger(DefaultAppender.class.getClass());

	public String getMaxFileSize() {
		return maxFileSize;
	}

	public void setMaxFileSize(String maxFileSize) {
		this.maxFileSize = maxFileSize;
	}

	public int getMaxFileBackup() {
		return maxFileBackup;
	}

	public void setMaxFileBackup(int maxFileBackup) {
		this.maxFileBackup = maxFileBackup;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public String getDateFormate() {
		return dateFormate;
	}

	public void setDateFormate(String dateFormate) {
		this.dateFormate = dateFormate;
	}

	public String getConvertionPattern() {
		return ConvertionPattern;
	}

	public void setConvertionPattern(String convertionPattern) {
		ConvertionPattern = convertionPattern;
	}
	public LevelRangeFilter addLevelRangeFilter(Level maxLevel,Level minLevel)
	{
		LevelRangeFilter filter=new  LevelRangeFilter();
		filter.setLevelMax(maxLevel);
		filter.setLevelMin(minLevel);		
		return filter;	
	}

	public Logger getLogger(boolean consoleAppender, boolean fileAppender) {
		
		if (consoleAppender) {
			log.addAppender(getBasicConsolAppender("Console Appender"));
		}
		if (fileAppender) {
			log.addAppender(getBasicRollingAppender("File Appender"));
		}
		return log;
	}

	public sp_Logger.RollingFileAppender getBasicRollingAppender(String name) {
		
		sp_Logger.RollingFileAppender rollingAppender = null;
		try {
			rollingAppender = new sp_Logger.RollingFileAppender();
			rollingAppender.setLayout(new PatternLayout(ConvertionPattern));
			rollingAppender.setName(name);
			rollingAppender.setFile(getFileName());
			rollingAppender.setMaxBackupIndex(getMaxFileBackup());
			rollingAppender.setMaxFileSize(getMaxFileSize());
			rollingAppender.activateOptions();
			return rollingAppender;
		} catch (IOException e) {
			e.printStackTrace();
		}

		return rollingAppender;
	}

	public ConsoleAppender getBasicConsolAppender(String name) {
		ConsoleAppender ca = new ConsoleAppender();
		ca.setLayout(new PatternLayout(ConvertionPattern));
		ca.setTarget("System.out");
		ca.setName(name);
		ca.activateOptions();
		return ca;
	}

	// TODO Method for append log to the Console
	public ConsoleAppender getBasicConsolAppender(String name,String ConvertionPattern, String target, boolean append) {
		ConsoleAppender ca = new ConsoleAppender();
		ca.setLayout(new PatternLayout(ConvertionPattern));
		ca.setTarget(target);
		ca.setName(name);
		if (append)
			ca.activateOptions();
		return ca;
	}

	// TODO Method for append log to the database
	public JDBCAppender getBasicJdbcAppender(String pattern, String driver,String url, String user, String password, String sqlQuery) {
		PatternLayout layout = new PatternLayout();
		String conversionPattern = pattern;
		layout.setConversionPattern(conversionPattern);
		JDBCAppender DB = new JDBCAppender();
		DB.setDriver(driver);
		DB.setLayout(layout);
		DB.setURL(url);
		DB.setUser(user);
		DB.setPassword(password);
		DB.setSql(sqlQuery);
		return DB;
	}

}

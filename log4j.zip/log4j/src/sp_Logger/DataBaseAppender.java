package sp_Logger;

import java.sql.Connection;
import java.sql.SQLException;

import org.apache.log4j.Appender;
import org.apache.log4j.PatternLayout;
import org.apache.log4j.jdbc.JDBCAppender;
import org.apache.log4j.spi.Filter;

public class DataBaseAppender extends JDBCAppender{
	
	String DbconversationPattern;
	
	
	
	public String getDbconversationPattern() {
		return DbconversationPattern;
	}
	public void setDbconversationPattern(String dbconversationPattern) {
		DbconversationPattern = dbconversationPattern;
	}
	public Connection getDbConnection() throws SQLException
	{
		return super.getConnection();
	}
	public String getDbPassword()
	{
		return super.getPassword();
	}
	public String getDbUserName()
	{
		return super.getUser();
	}
	public String getDbUrl()
	{
		return super.getURL();
	}
	public int getBufferSize()
	{
		return super.getBufferSize();
	}
	
	public void setDbDriver(String driver) {
		super.setDriver(driver);		
	}
	public void setDbUrl(String url) {
		super.setURL(url);		
	}
	public void setDbUserName(String UserName) {
		super.setUser(UserName);		
	}
	public void setDbPassword(String PassWord) {
		super.setPassword(PassWord);		
	}
	public void SetSqlQuery(String Query) {
		super.setSql(Query);
	}	
	public void setBufferSize(int bufferSize)
	{
		super.setBufferSize(bufferSize);
	}
	
	
	public void activateOptions()
	{
		super.activateOptions();
	}

	public void addFilter(Filter filter)
	{
		super.addFilter(filter);
	}
	
	public DataBaseAppender() {
		// TODO Auto-generated constructor stub
	}
	
	public Appender getJdbcAppender(String pattern,String driver,String url,String user,String password,String sqlQuery)
	{
		PatternLayout layout = new PatternLayout();
		String conversionPattern = pattern;
		layout.setConversionPattern(conversionPattern);
		JDBCAppender DB=new JDBCAppender();
		DB.setDriver(driver);
		DB.setLayout(layout);
		DB.setURL(url);
		DB.setUser(user);
		DB.setPassword(password);
		DB.setSql(sqlQuery);		
		return DB;
	}	
	
	
	
}

package sp_Logger;

import java.io.File;
import java.io.IOException;
import java.nio.file.Path;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import org.apache.log4j.Layout;

public class RollingFileAppender extends org.apache.log4j.RollingFileAppender {

	private String fixedFileName;
	private String dateFormate = "yyyy-MM-dd HH.mm.ss";
	private File dir;
	private String filePath;

	public void setMaxBackupIndex(int maxBackupCount) {
		super.setMaxBackupIndex(maxBackupCount);
	}

	public int getMaxBackupIndex() {
		return super.getMaxBackupIndex();
	}

	public void setMaxFileSize(String value) {
		super.setMaxFileSize(value);
	}

	public long getMaxFileSize() {
		return super.getMaximumFileSize();
	}

	public void activateOperation() {
		super.activateOptions();
	}

	private String getTmpFileName() {
		String dateFormat = new SimpleDateFormat(dateFormate).format(new Date());
		String baseFileName = fixedFileName + "__" + dateFormat;
		return baseFileName + ".log";
	}

	public void createFolder() throws IOException {
		dir = new File("logs");
		dir.mkdirs();
		this.filePath = dir.getAbsolutePath() + "\\";
		System.out.println("File_Path  : "+filePath);
	}

	@Override
	public void setFile(String file) {
		if (fixedFileName == null)
			fixedFileName = file;
		super.setFile(filePath + getTmpFileName());
		// System.out.println("called set file : " + fixedFileName);
	}

	@Override
	public void rollOver() {
		closeFile();
		setFile(getTmpFileName());
		System.out.println("Roll over called");
		super.rollOver();
	}

	public RollingFileAppender() throws IOException {
		super();
		createFolder();
	}

	public RollingFileAppender(Layout layout, String name) throws IOException {
		super(layout, name);
	}

	public RollingFileAppender(Layout layout, String name, boolean append)
			throws IOException {
		super(layout, name, append);
	}

}

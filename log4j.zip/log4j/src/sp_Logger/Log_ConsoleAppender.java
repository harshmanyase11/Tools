package sp_Logger;

import org.apache.log4j.ConsoleAppender;
import org.apache.log4j.Layout;
import org.apache.log4j.PatternLayout;
import org.apache.log4j.spi.LoggingEvent;

public class Log_ConsoleAppender extends ConsoleAppender {
	
	
	public void setName(String name)
	{
		super.setName(name);
	}
	public void setTarget(String target)
	{
		super.setTarget(target);
	}
	public String getTarget()
	{
		return super.getTarget();
	}
	
	public Log_ConsoleAppender() {
		// TODO Auto-generated constructor stub
	}
	public Log_ConsoleAppender(Layout layout) {
		super(layout);
	}
	public Log_ConsoleAppender(Layout layout,String target) {
		super(layout, target);
	}
    
	public void activateConsoleAppender(boolean input)
	{
		if(input)
		{
			activateOptions();
		}	
	}
	public ConsoleAppender getBasicConsolAppender(String name,String conversationPattern,String target)
	{
		ConsoleAppender ca = new ConsoleAppender();
	      ca.setLayout(new PatternLayout(conversationPattern));
	      ca.setTarget(target);
	      ca.setName(name);	      
	      ca.activateOptions();     
	      return ca;
	}
	public ConsoleAppender getBasicConsolAppender(String name,PatternLayout patternLayout,String target,boolean append)
	{
		ConsoleAppender ca = new ConsoleAppender();
	      ca.setLayout(patternLayout);
	      ca.setTarget(target);
	      ca.setName(name);	 
	      if(append)
	      {
	      ca.activateOptions();   
	      }
	      return ca;
	}
	
	public ConsoleAppender getBasicConsolAppender()
	{
		 ConsoleAppender ca = new ConsoleAppender();
	      ca.setLayout(new PatternLayout("%5d - %5t - %5p  - (%F:%L) - %m%n"));
	      ca.setTarget("System.out");
	      ca.setName("Console Appender");	      
	      ca.activateOptions();
	      return ca;
	}
}

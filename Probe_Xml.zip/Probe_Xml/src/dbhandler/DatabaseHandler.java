package dbhandler;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.StringTokenizer;
import logger.LogHandler;
import pojo.MEAS_DATA;
import pojo.MEAS_HEADER;
import pojo.MEAS_VALUES;
import dao.DataBase_Connection;

public class DatabaseHandler {

	Connection conInstance;
	private Statement smtInstance;
	
	public DatabaseHandler() {
		 DataBase_Connection.setConfigFileName("DBconfig.properties");
		   conInstance=DataBase_Connection.getConnectionInstance();
	}
	
	
	public void save3GPP_MEAS_HEADER(MEAS_HEADER measHeader)
	{
            
			try {
				
				String query = "insert into T_3GPP_MEAS_HEADER values('"+measHeader.getBeginTime()+"','"+measHeader.getFileFormatVersion()+"','"+measHeader.getVendorName()+"','"+measHeader.getDnPrefix()+"','"+measHeader.getLocalDn()+"','"+measHeader.getElementType()+"','"+measHeader.getEndTime()+"')";
				smtInstance = conInstance.createStatement();
				boolean result = smtInstance.execute(query);
				
				if (result)
				{
					System.out.println("Error : 3GPP_MEAS_HEADER not inserted into DATABASE");
					LogHandler.xmlParserLogger.info("Error : 3GPP_MEAS_HEADER not inserted into DATABASE");
				}
				else	
				{
				    System.out.println("3GPP_MEAS_HEADER inserted into DATABASE");
				    LogHandler.xmlParserLogger.info(" 3GPP_MEAS_HEADER  inserted into DATABASE");
				}
			} catch (SQLException ex) { 
				LogHandler.xmlParserLogger.debug("Error is :"+ex.getMessage());
				ex.printStackTrace();
				
			} finally {
				try {
					if (smtInstance != null)
						smtInstance.close();
				} catch (SQLException e) {
					LogHandler.xmlParserLogger.debug("Error is  : "+e.getMessage());
					e.printStackTrace();
				}
			}	
		}
	
	public void save3GPP_MEAS_DATA(MEAS_DATA measData)
	{
		
			try {
				String version;
				if(measData.getManagedElemnt_SW_Version()!= null)
				{
					version=measData.getManagedElemnt_SW_Version();
				}
				else
				{
					version=" ";
				}
				String query = "insert into T_3GPP_MEAS_DATA values('"+measData.getBeginTime()+"',"+Integer.parseInt(measData.getJobId())+",'"+measData.getGranPeriodDuration()+"','"+measData.getGranPeriodEndTime()+"','"+measData.getRepPeriodDuration()+"','"+measData.getManagedElemnt_LocalDn()+"','"+measData.getManagedElemnt_UserLabel()+"','"+version+"')";
				smtInstance = conInstance.createStatement();
				int result = smtInstance.executeUpdate(query);
				if (result != 0)
				{
					System.out.println("3GPP_MEAS_DATA inserted into DATABASE");
					LogHandler.xmlParserLogger.info("3GPP_MEAS_DATA inserted into DATABASE");
				}
				else
				{
					System.out.println("Error : 3GPP_MEAS_DATA not inserted into DATABASE");
					LogHandler.xmlParserLogger.info("Error : 3GPP_MEAS_DATA not inserted into DATABASE");
					
				}
			} catch (SQLException ex) {
				ex.printStackTrace();
				
			} finally {
				
				try {
					if (smtInstance != null)
						smtInstance.close();
				} catch (SQLException e) {
					LogHandler.xmlParserLogger.info("Error is:"+e.getMessage());					
					e.printStackTrace();
				}
			}	
		
	}
	
	public void save3GPP_MEAS_Values(MEAS_VALUES measValues)
	{
				
			try {
				//LinkedHashMap<String, String> measHeader
				
				String query = "insert into T_3GPP_MEAS_VALUES values('"+measValues.getBeginTime()+"','"+measValues.getJobid()+"','"+measValues.getMeasObjLdn()+"','"+measValues.getMeasType()+"','"+measValues.getMeasResult()+"')";
				smtInstance = conInstance.createStatement();
				boolean result = smtInstance.execute(query);
				
				if (result)
					System.out.println("Error : 3GPP_MEAS_Values not inserted into DATABASE");
				else					
				    System.out.println("3GPP_MEAS_Values inserted into DATABASE");
			} catch (SQLException ex) {
				ex.printStackTrace();
				
			} finally {
				try {
					if (smtInstance != null)
						smtInstance.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}	
		}
	
	public ArrayList<String> StringTokenizer(String input,String delimeter)
	{
		ArrayList<String> temp=new ArrayList<String>();
		StringTokenizer st = new StringTokenizer(input,delimeter);  
	     while (st.hasMoreTokens()) { 
	    	 String value=st.nextToken();
	         //System.out.println(value);
	         temp.add(value);
	     }
		return temp; 
	}
	public void printArrayList(ArrayList<String> arraylist)
	{
		System.out.println("----------------------------");
		for (String string : arraylist) {
			System.out.println(string);
		}
	}
	public static void main(String[] args) {
		
         DatabaseHandler handle=new DatabaseHandler();
         //handle.save3GPP_MEAS_HEADER();
         ArrayList<String> list=new ArrayList<String>();
        list= handle.StringTokenizer("MM.AttGprsAttach MM.SuccGprsAttach MM.AbortedGprsAttach MM.AttIntraSgsnRaUpdate", " ");
		for (String string : list) {
			System.out.println(string);
		}
	}

}

package xml;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Set;
import java.util.StringTokenizer;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import oracle.xml.parser.v2.XMLDocument;
import oracle.xml.parser.v2.XMLNode;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.w3c.dom.traversal.NodeFilter;
import org.w3c.dom.traversal.TreeWalker;
import org.xml.sax.SAXException;

import pojo.MEAS_HEADER;
import pojo.MEAS_VALUES;

public class XmlParserMode2 {

	
	private LinkedHashMap<String, String> measType;
	private LinkedHashMap<String, ArrayList<String>> measValues;
	private LinkedHashMap<String, ArrayList<String>> measResults;
	private String inputXmlFileName;
	private String measObjLdn;
	private String endTime;
	
   
	/**
	 * @return the inputXmlFileName
	 */
	public String getInputXmlFileName() {
		return inputXmlFileName;
	}

	/**
	 * @param inputXmlFileName the inputXmlFileName to set
	 */
	public void setInputXmlFileName(String inputXmlFileName) {
		this.inputXmlFileName = inputXmlFileName;
	}

	public XmlParserMode2() {
		// TODO Auto-generated constructor stub
		measValues = new LinkedHashMap<String, ArrayList<String>>();
		measValues.clear();
		measType = new LinkedHashMap<String, String>();
		measType.clear();
		measResults = new LinkedHashMap<String, ArrayList<String>>();
		measResults.clear();
	}


	public Document parseDocument(String fileName) {
		File fXmlFile = new File(fileName);
		DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
		DocumentBuilder dBuilder;
		try {
			dBuilder = dbFactory.newDocumentBuilder();
			Document doc = dBuilder.parse(fXmlFile);
			// printElements(doc);
			doc.normalize();
			return doc;
		} catch (ParserConfigurationException | SAXException | IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;

	}
	public String getEndTime(Document doc)
	{
		NodeList nl = doc.getElementsByTagName("*");
		   Element e;
		   Node n;
		   NamedNodeMap nnm;
		 
		   String attrname;
		   String attrval;
		   int i, len;
		 
		   len = nl.getLength();

		   for (int j=0; j < len; j++)
		   {
		      e = (Element)nl.item(j);
		      System.out.println(e.getTagName() + ":");
		      nnm = e.getAttributes();
		 
		      if (nnm != null)
		      {
		         for (i=0; i<nnm.getLength(); i++)
		         {
		            n = nnm.item(i);
		            attrname = n.getNodeName();
		            attrval = n.getNodeValue();
		           // System.out.print(" " + attrname + " = " + attrval);
		            if(attrname.equals("endTime"))
		            {
		            	this.endTime=attrval;
		            	return endTime;
		            }
		         }
		      }
		      System.out.println();
		   }
		return endTime;
	}

	public void parse()  {		
		
	     
        
		XmlParserMode2 d = new XmlParserMode2();
		getEndTime(d.parseDocument(inputXmlFileName));
		XMLDocument doc = (XMLDocument) d.parseDocument(inputXmlFileName);;
		Nodefilter n2 = new Nodefilter();
		TreeWalker tw = doc.createTreeWalker(doc.getDocumentElement(),
				NodeFilter.SHOW_ALL, n2, true);
		doc.getElementsByTagName("measCollec");
		XMLNode nn = (XMLNode) tw.getRoot();
		while (nn != null) {

			String nodeName = nn.getNodeName();
			String nodeValue = nn.getTextContent();
			// System.out.println(nodeName);
			String attnodeName = null;
			String attnodeValues = null;

			switch (nodeName) {
			case "fileHeader":
				System.out.println(nodeName);
				for (int j = 0; j < nn.getAttributes().getLength(); j++) {
					System.out.println();
					attnodeName = nn.getAttributes().item(j).getNodeName();
					attnodeValues = nn.getAttributes().item(j).getNodeValue();
					System.out.printf("att   :"
							+ nn.getAttributes().item(j).getNodeName()
							+ "  att val  :   "
							+ nn.getAttributes().item(j).getNodeValue());
					d.addValues(attnodeName, attnodeValues);
				}
				System.out.println("val    :" + nodeValue);
				d.addValues(nodeName, nodeValue);

				break;
			case "fileSender":
				System.out.println(nodeName);
				for (int j = 0; j < nn.getAttributes().getLength(); j++) {
					System.out.println();
					attnodeName = nn.getAttributes().item(j).getNodeName();
					attnodeValues = nn.getAttributes().item(j).getNodeValue();
					System.out.printf("att   :"
							+ nn.getAttributes().item(j).getNodeName()
							+ "  att val  :   "
							+ nn.getAttributes().item(j).getNodeValue());
					d.addValues(attnodeName, attnodeValues);
				}
				System.out.println("val    :" + nodeValue);
				d.addValues(nodeName, nodeValue);
				break;
			case "measCollec":
				System.out.println(nodeName);
				for (int j = 0; j < nn.getAttributes().getLength(); j++) {
					System.out.println();
					attnodeName = nn.getAttributes().item(j).getNodeName();
					attnodeValues = nn.getAttributes().item(j).getNodeValue();
					System.out.printf("att   :"
							+ nn.getAttributes().item(j).getNodeName()
							+ "  att val  :   "
							+ nn.getAttributes().item(j).getNodeValue());
					d.addValues(attnodeName, attnodeValues);
				}
				System.out.println("val    :" + nodeValue);
				d.addValues(nodeName, nodeValue);
				break;
			case "managedElement":
				
				System.out.println(nodeName);
				for (int j = 0; j < nn.getAttributes().getLength(); j++) {
					System.out.println();
					attnodeName = nn.getAttributes().item(j).getNodeName();
					attnodeValues = nn.getAttributes().item(j).getNodeValue();
					System.out.printf("att   :"
							+ nn.getAttributes().item(j).getNodeName()
							+ "  att val  :   "
							+ nn.getAttributes().item(j).getNodeValue());
					d.addValues(attnodeName, attnodeValues);
				}
				System.out.println("val    :" + nodeValue);
				 d.addValues(nodeName, nodeValue);
				 MEAS_HEADER sn=new MEAS_HEADER();
				 sn.setBeginTime(d.measValues.get("beginTime").get(0));
				 sn.setDnPrefix(d.measValues.get("localDn").get(0));
				 sn.setFileFormatVersion(d.measValues.get("fileFormatVersion").get(0));
				 sn.setElementType(d.measValues.get("elementType").get(0));
				 sn.setEndTime(d.endTime);
				 sn.setLocalDn(d.measValues.get("localDn").get(0));
				 sn.setVendorName(d.measValues.get("vendorName").get(0));
				System.out.println(sn.toString());
				break;
			case "job":
				System.out.println(nodeName);
				for (int j = 0; j < nn.getAttributes().getLength(); j++) {
					System.out.println();
					attnodeName = nn.getAttributes().item(j).getNodeName();
					attnodeValues = nn.getAttributes().item(j).getNodeValue();
					System.out.printf("att   :"
							+ nn.getAttributes().item(j).getNodeName()
							+ "  att val  :   "
							+ nn.getAttributes().item(j).getNodeValue());
					d.addValues(attnodeName, attnodeValues);
				}
				System.out.println("val    :" + nodeValue);
				d.addValues(nodeName, nodeValue);
				break;
			case "granPeriod":
				System.out.println(nodeName);
				for (int j = 0; j < nn.getAttributes().getLength(); j++) {
					System.out.println();
					attnodeName = nn.getAttributes().item(j).getNodeName();
					attnodeValues = nn.getAttributes().item(j).getNodeValue();
					System.out.printf("att   :"
							+ nn.getAttributes().item(j).getNodeName()
							+ "  att val  :   "
							+ nn.getAttributes().item(j).getNodeValue());
					d.addValues(attnodeName, attnodeValues);
				}
				System.out.println("val    :" + nodeValue);
				d.addValues(nodeName, nodeValue);
				break;
			case "repPeriod":
				System.out.println(nodeName);

				for (int j = 0; j < nn.getAttributes().getLength(); j++) {
					System.out.println();
					attnodeName = nn.getAttributes().item(j).getNodeName();
					attnodeValues = nn.getAttributes().item(j).getNodeValue();
					System.out.printf("att   :"
							+ nn.getAttributes().item(j).getNodeName()
							+ "  att val  :   "
							+ nn.getAttributes().item(j).getNodeValue());
					d.addValues(attnodeName, attnodeValues);
					
				}
				System.out.println("val    :" + nodeValue);
				d.addValues(nodeName, nodeValue);
				break;
			case "measType":
				System.out.println(nodeName);

				for (int j = 0; j < nn.getAttributes().getLength(); j++) {
					System.out.println();
					attnodeName = nn.getAttributes().item(j).getNodeName();
					attnodeValues = nn.getAttributes().item(j).getNodeValue();
					System.out.printf("att   :"
							+ nn.getAttributes().item(j).getNodeName()
							+ "  att val  :   "
							+ nn.getAttributes().item(j).getNodeValue());
					// d.addValues(attnodeName, attnodeValues);
					// d.addValues(nodeName, nodeValue);
					d.measType.put(attnodeValues, nodeValue);
				}
				System.out.println("val    :" + nodeValue);
				break;
			case "measValue":
				System.out.println(nodeName);
				for (int j = 0; j < nn.getAttributes().getLength(); j++) {
					System.out.println();
					attnodeName = nn.getAttributes().item(j).getNodeName();
					attnodeValues = nn.getAttributes().item(j).getNodeValue();
					System.out.printf("att   :"+ nn.getAttributes().item(j).getNodeName()+ "  att val  :   "
							+ nn.getAttributes().item(j).getNodeValue());
					measObjLdn=attnodeValues;
				}
				
				
				System.out.println("val    :" + nodeValue);
				
				break;
			case "r":
				System.out.println(nodeName);
				for (int j = 0; j < nn.getAttributes().getLength(); j++) {
					System.out.println();
					attnodeName = nn.getAttributes().item(j).getNodeName();
					attnodeValues = nn.getAttributes().item(j).getNodeValue();
					System.out.printf("att name   :"
							+ nn.getAttributes().item(j).getNodeName()
							+ "  att value  :   "
							+ nn.getAttributes().item(j).getNodeValue());
					//d.addValues(attnodeName, attnodeValues);
					d.addResult(attnodeValues, nodeValue);
					MEAS_VALUES measval=new MEAS_VALUES();
					measval.setBeginTime(d.measValues.get("beginTime").get(0));
					measval.setJobid(Integer.parseInt(d.measValues.get("jobId").get(0)));
					measval.setMeasObjLdn(measObjLdn);
					measval.setMeasResult(nodeValue);
					measval.setMeasType(d.measType.get(attnodeValues));
					System.out.println("meas value obj :"+measval.toString());
				    //measval.setMeasObjLdn(measObjLdn);
				}
				System.out.println("val    :" + nodeValue);
				// d.addValues(nodeName, nodeValue);
				
				break;
			default:
				break;
			}
			nn = (XMLNode) tw.nextNode();
		}
		//d.printMeasValues();
		//System.out.println("-----------------------------------------");
		//System.out.println(d.measValues.get("beginTime"));
		//d.print(d.measType);
		//System.out.println("-----------------------------------------");
		//d.printMeasResult();
	}
	private void addValues(String key, String value) {
		ArrayList<String> tempList = null;
		if (measValues.containsKey(key)) {
			tempList = measValues.get(key);
			if (tempList == null)
				tempList = new ArrayList<String>();
			tempList.add(value);
		} else {
			tempList = new ArrayList<String>();
			tempList.add(value);
		}
		measValues.put(key, tempList);
	}
	private void addResult(String key, String value) {
		ArrayList<String> tempList = null;
		if (measResults.containsKey(key)) {
			tempList = measResults.get(key);
			if (tempList == null)
				tempList = new ArrayList<String>();
			tempList.add(value);
		} else {
			tempList = new ArrayList<String>();
			tempList.add(value);
		}
		measResults.put(key, tempList);
	}

	

	public void printMeasValues() {
		System.out.println("---meas value ---");
		Iterator<String> it = measValues.keySet().iterator();
		ArrayList<String> tempList = null;

		while (it.hasNext()) {
			String key = it.next().toString();
			tempList = measValues.get(key);
			if (tempList != null) {
				for (String value : tempList) {
					System.out.println("Key : " + key + " , Value : " + value);
				}
			}
		}

	}
	public void printMeasResult() {
		System.out.println("---meas Result ---");
		Iterator<String> it = measResults.keySet().iterator();
		ArrayList<String> tempList = null;

		while (it.hasNext()) {
			String key = it.next().toString();
			tempList = measResults.get(key);
			if (tempList != null) {
				for (String value : tempList) {
					System.out.println("Key : " + key + " , Value : " + value);
				}
			}
		}

	}
	

	public ArrayList<String> StringTokenizer(String input, String delimeter) {
		ArrayList<String> temp = new ArrayList<String>();
		StringTokenizer st = new StringTokenizer(input, delimeter);
		while (st.hasMoreTokens()) {
			String value = st.nextToken();
			// System.out.println(value);
			temp.add(value);
		}
		return temp;
	}

	public void printArrayList(ArrayList<String> arraylist) {
		System.out.println("----------------------------");
		for (String string : arraylist) {
			System.out.println(string);
		}
	}


	public void print(LinkedHashMap<String, String> linkedList) {
		Set<String> set = linkedList.keySet();
		System.out.println("-------------------");
		System.out.println("key      " + "     Values");
		for (String key : set) {
			String value = linkedList.get(key);
			System.out.println(key + " " + value);
		}

	}

	public static void main(String[] args) {

		XmlParserMode2 tw=new XmlParserMode2();
		tw.setInputXmlFileName("./xml test files/A2.TS32.435.v11.0.0.xml");
		tw.parse();
		
		//System.out.println(tw.getEndTime(doc));
	}
}

class Nodefilter implements NodeFilter {
	public short acceptNode(Node node) {
		short type = node.getNodeType();

		if ((type == Node.ELEMENT_NODE) || (type == Node.ATTRIBUTE_NODE))
			return FILTER_ACCEPT;
		if ((type == Node.ENTITY_REFERENCE_NODE))
			return FILTER_REJECT;
		return FILTER_SKIP;
	}
}
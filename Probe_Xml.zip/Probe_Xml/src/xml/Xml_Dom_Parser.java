package xml;

import java.io.File;
import java.io.IOException;
import java.sql.Connection;
import java.sql.Statement;
import java.util.LinkedHashMap;
import java.util.Set;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import dao.DataBase_Connection;


public class Xml_Dom_Parser {
	
	private Statement smtInstance=null;
	private String xmlFileName;
	private DataBase_Connection daoInstance;
	private Connection conInstance;	
    public LinkedHashMap<String, String> xml_Data;
	
	public Statement getSmtInstance() {
		return smtInstance;
	}
	public void setSmtInstance(Statement smtInstance) {
		this.smtInstance = smtInstance;
	}
	public String getXmlFileName() {
		return xmlFileName;
	}
	public void setXmlFileName(String xmlFileName) {
		this.xmlFileName = xmlFileName;
	}
	public DataBase_Connection getDaoInstance() {
		return daoInstance;
	}
	public void setDaoInstance(DataBase_Connection daoInstance) {
		this.daoInstance = daoInstance;
	}
	public Connection getConInstance() {
		return conInstance;
	}
	public void setConInstance(Connection conInstance) {
		this.conInstance = conInstance;
	}
	
	
	protected String getNodeValue( Node node ) {
	    NodeList childNodes = node.getChildNodes();
	    for (int x = 0; x < childNodes.getLength(); x++ ) {
	        Node data = childNodes.item(x);
	        if ( data.getNodeType() == Node.TEXT_NODE )
	            return data.getNodeValue();
	    }
	    return "";
	}
	 
	public String getNodeValue(String tagName, NodeList nodes ) {
	    for ( int x = 0; x < nodes.getLength(); x++ ) {
	        Node node = nodes.item(x);
	        if (node.getNodeName().equalsIgnoreCase(tagName)) {
	            NodeList childNodes = node.getChildNodes();
	            for (int y = 0; y < childNodes.getLength(); y++ ) {
	                Node data = childNodes.item(y);
	                if ( data.getNodeType() == Node.TEXT_NODE )
	                    return data.getNodeValue();
	            }
	        }
	    }
	    return "";
	}
	public Xml_Dom_Parser() {
		// TODO Auto-generated constructor stub
		conInstance=DataBase_Connection.getConnectionInstance();
		xml_Data=new LinkedHashMap<String, String>();
		
	}
	public void parseDocument(String fileName)
	{
		File fXmlFile = new File(fileName);
		DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
		DocumentBuilder dBuilder;
		try {
			dBuilder = dbFactory.newDocumentBuilder();
			Document doc = dBuilder.parse(fXmlFile);
			//printElements(doc);
		    parse(doc);
			
		} catch (ParserConfigurationException | SAXException | IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
				
	}
	
	public  void parse(Document doc)
	   {
	      NodeList nl = doc.getElementsByTagName("*");
	      Element e;
	      Node n;
	      NamedNodeMap nnm;

	      String attrname;
	      String attrval;
	      int i, len;

	      len = nl.getLength();
	      System.out.println();
	      for (int j=0; j < len; j++)
	      {
	         e = (Element)nl.item(j);
	         String tagName=e.getTagName();
	         System.out.print(tagName + ":");
	         nnm = e.getAttributes();
	         if (nnm != null)
	         {
	            for (i=0; i<nnm.getLength(); i++)
	            {	            	
	               n = nnm.item(i);
	               attrname = n.getNodeName();
	               attrval = n.getNodeValue();
	               System.out.print(" " + attrname + " = " + attrval);
	               xml_Data.put(attrname, attrval);
	               if(attrname=="endTime")
	               {
	            	   System.out.println("--------------------"+attrval);
	               }
	            }
	         }
	    // System.out.print(" "+ e.getTextContent());
	    // xml_Data.put(tagName, e.getTextContent());
	         /*if(!tagName.equals(""))
	         {
	     System.out.println("value : " + e.getElementsByTagName(tagName).item(1).getTextContent());
	         }
	        */
	         System.out.println();
	       
	         //System.out.println(e.getTagName());
	         
	      }
	   }
	public void printValues()
	{
		Set<String> set=xml_Data.keySet();
		System.out.println("Set values  :"+set);
		System.out.println("-------------------");
		System.out.println("key      "+"     Values");
		for(String key :set)
		{
			String value=xml_Data.get(key);
			System.out.println(key +" "+value);
		}
		
	}
	static void printElements(Document doc)
	   {
	      NodeList nl = doc.getElementsByTagName("*");
	      Node n;	         
	      for (int i=0; i<nl.getLength(); i++)
	      {
	         n = nl.item(i);
	         Element e=(Element) nl.item(i);
	         String nodename=n.getNodeName();
	         System.out.println(nodename + " ");
	        System.out.println(e.getElementsByTagName(nodename).item(0));
	      }

	      System.out.println();
	   }
	
	
	public static void main(String[] args) {
		DataBase_Connection.setConfigFileName("DBconfig.properties");
		DataBase_Connection.getConnectionInstance();
        Xml_Dom_Parser dom=new Xml_Dom_Parser();
		/*dom.setXmlFileName("./xml test files/A1.TS32.435.v11.0.0.xml");
		dom.setXmlFileName("./xml test files/A2.TS32.435.v11.0.0.xml");
		dom.setXmlFileName("./xml test files/A3.TS32.435.v11.0.0.xml");
		dom.readxml();*/
		String file1="./xml test files/A1.TS32.435.v11.0.0.xml";
		String file2="./xml test files/A2.TS32.435.v11.0.0.xml";
		String file3="./xml test files/A3.TS32.435.v11.0.0.xml";
		dom.parseDocument(file1);
		//dom.printValues();
		//dom.readxml(file1);
		
		/*try {
			DataBase_Connection.closeConnection();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/
	}

}

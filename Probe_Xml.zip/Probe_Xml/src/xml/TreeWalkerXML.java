package xml;

import java.io.File;
import java.io.IOException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import oracle.xml.parser.v2.XMLDocument;
import oracle.xml.parser.v2.XMLNode;
import oracle.xml.parser.v2.XMLNodeList;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.traversal.NodeFilter;
import org.w3c.dom.traversal.TreeWalker;
import org.xml.sax.SAXException;

public class TreeWalkerXML {

	public Document parseDocument(String fileName)
	{
		File fXmlFile = new File(fileName);
		DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
		DocumentBuilder dBuilder;
		try {
			dBuilder = dbFactory.newDocumentBuilder();
			Document doc = dBuilder.parse(fXmlFile);
			//printElements(doc);
		    return doc;
		} catch (ParserConfigurationException | SAXException | IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
				
	}
	public static void main(String[] args) {
		TreeWalkerXML d=new TreeWalkerXML();
		
		XMLDocument doc = (XMLDocument) d.parseDocument("./xml test files/A1.TS32.435.v11.0.0.xml");
		
	    Nodefilter n2=new Nodefilter();
	
		TreeWalker tw = doc.createTreeWalker(doc.getDocumentElement(),NodeFilter.SHOW_ALL,n2,true);
		
		XMLNode nn = (XMLNode)tw.getRoot();
		while (nn != null)
		{
		  System.out.println(nn.getNodeName());
		  
			for(int j=0;j<nn.getAttributes().getLength();j++)
			{	        
				System.out.println();
				System.out.println(nn.getAttributes().item(j).getNodeName());
			   System.out.println(nn.getAttributes().item(j).getNodeValue());
			   
			}
			 System.out.println(nn.getTextContent() );
		  nn = (XMLNode)tw.nextNode();
		}
	}

}
class Nodefilter implements NodeFilter
{
  public short acceptNode(Node node)
  {
    short type = node.getNodeType();
 
    if ((type == Node.ELEMENT_NODE) || (type == Node.ATTRIBUTE_NODE))
       return FILTER_ACCEPT;
    if ((type == Node.ENTITY_REFERENCE_NODE))
       return FILTER_REJECT;
    return FILTER_SKIP;
  }
}
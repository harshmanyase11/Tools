package xml;




import java.io.File;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;

import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import logger.LogHandler;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

import dao.DataBase_Connection;

public class SAXParserDemo {
	
	
	
	   public static void main(String[] args){

	      try {	
	    	  new LogHandler();
	    	 // DataBase_Connection.setConfigFileName("DBconfig.properties");
	         File inputFile = new File("./xml test files/A2.TS32.435.v11.0.0.xml");
	         SAXParserFactory factory = SAXParserFactory.newInstance();
	         SAXParser saxParser = factory.newSAXParser();
	         UserHandler userhandler = new UserHandler();
	         saxParser.parse(inputFile, userhandler);  
	         DataBase_Connection.closeConnection();
	         userhandler.printValues();
	      } catch (Exception e) {
	         e.printStackTrace();
	      }
	   }   
	}

	class UserHandler extends DefaultHandler {
		
		private Statement smtInstance=null;		
		private Connection conInstance;		
       Set<String> tagList;   
       String currentTagName;
       public LinkedHashMap<String, String> xml_Data;
       public Map<String, ArrayList<String>> measValues;
       public LinkedHashMap<String, LinkedHashMap<String, String>> measDATA;
       public void printValues()
       {
    	   /*System.out.println("Tag List Values ");
    	  for (String string : tagList) {
			System.out.println(string);
		     }    */
    	   if(xml_Data!=null)
    	   {
	    	   Set<String> set=xml_Data.keySet();
	    	   System.out.println("---------------------");
	    	   for(String key:set)
	    	   {
	    		   String value=xml_Data.get(key);
	    		   System.out.println(key+"     "+value);
	    	   }
    	   }
    	   
    	   printMeasValues();
    	   
       }
	   public UserHandler() {
		   //studentObj=new Student_Pojo();
			//this.conInstance=DataBase_Connection.getConnectionInstance();
			tagList=new LinkedHashSet<String>();
			tagList.clear();
			xml_Data=new LinkedHashMap<String, String>();
			xml_Data.clear();
			measValues= new HashMap<String, ArrayList<String>>();
			measValues.clear();
			measDATA=new LinkedHashMap<String, LinkedHashMap<String,String>>();
		}
		
	   @Override
	   public void startElement(String uri, 
	      String localName, String qName, Attributes attributes)
	         throws SAXException {
		   currentTagName=qName;
		  
		   for (int i=0;i<attributes.getLength();i++)
		   {
		     String aname = attributes.getQName(i);		   
		     String value = attributes.getValue(i); 
		     System.out.println("  att "+aname+"   "+"="+value);
		     xml_Data.put(aname, value);
		     addValues(aname, value);
		     //measDATA.put(qName, );		     
		   }  
	    
	   }

	   @Override
	   public void endElement(String uri, 
	      String localName, String qName) throws SAXException {
	     
	        // System.out.println("End Element :" + qName);
	      
	   }

	   @Override
	   public void characters(char ch[], 
	      int start, int length) throws SAXException {
		   String value=String.copyValueOf(ch, start, length).trim();
		   
		   
		   switch(currentTagName)
		   {
		   case "measTypes":
			                //xml_Data.putIfAbsent("measTypes", value);
			                 if(!value.isEmpty())
			                  addValues("measTypes", value);
			               // System.out.println("meas Types "+value);			                
			                break;
		   case "measResults":
			                // xml_Data.putIfAbsent("measResults", value);
			                  if(!value.isEmpty())
			                  addValues("measResults", value);
			                 //System.out.println("meas Result :"+value);
			                 break;
		   case "suspect":      if(value.isEmpty())
			                    xml_Data.putIfAbsent("suspect", value);
			                 break; 
		   
		   }
		   
		  
	   }
	   private void addValues(String key, String value) {
		   ArrayList<String> tempList = null;
		   if (measValues.containsKey(key)) {
		      tempList = measValues.get(key);
		      if(tempList == null)
		         tempList = new ArrayList<String>();
		      tempList.add(value);  
		   } else {
		      tempList = new ArrayList<String>();
		      tempList.add(value);               
		   }
		   measValues.put(key,tempList);
		}
	   @SuppressWarnings("unused")
	private void addValues(LinkedHashMap<String, LinkedHashMap<String, String>> mapOBJ,String key,String key2, String value) {
		   LinkedHashMap<String, String> tempList = null;
		   if (mapOBJ.containsKey(key)) {
		      tempList = mapOBJ.get(key);
		      if(tempList == null)
		         tempList = new LinkedHashMap<String, String>();
		      tempList.put(key2, value)  ;
		   } else {
		      tempList = new LinkedHashMap<String, String>();
		      tempList.put(key2, value);              
		   }
		   mapOBJ.put(key,tempList);
		}
	   public void printMap(LinkedHashMap<String, LinkedHashMap<String, String>> mapOBJ)
	   {
		   System.out.println("---meas value ---");
			Iterator it = mapOBJ.keySet().iterator();
			   LinkedHashMap<String, String> tempList = null;

			   while (it.hasNext()) {
			      String key = it.next().toString();             
			      tempList = mapOBJ.get(key);
			      if (tempList != null) {
			    	  Iterator it2=tempList.keySet().iterator();
			    	  
			    	  while(it2.hasNext())
			    	  {
			    		  String key2 = it.next().toString();
			    		  String values=   tempList.get(key2);
			    		  System.out.println(" Key1 : "+key+ " ,  key2  : "+key2+"  Value : "+values);
			    	  }
			    	 
			      }
			   }	
		    
	   }
	   public void printMeasValues()
		{System.out.println("---meas value ---");
			Iterator it = measValues.keySet().iterator();
			   ArrayList<String> tempList = null;

			   while (it.hasNext()) {
			      String key = it.next().toString();             
			      tempList = measValues.get(key);
			      if (tempList != null) {
			         for (String value: tempList) {
			            System.out.println("Key : "+key+ " , Value : "+value);
			         }
			      }
			   }	
			  
			  // System.out.println( "test  :"+measValues.get("localDn"));
		    }	  
	}
package xml;

import java.io.File;

import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

public class Xml_Parser  {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	      try {	
	         File inputFileA1 = new File("./xml test files/A1.TS32.435.v11.0.0.xml");
	         File inputFileA2=new File("./xml test files/A2.TS32.435.v11.0.0.xml");
	         File inputFileA3=new File("./xml test files/A3.TS32.435.v11.0.0.xml");
	         SAXParserFactory factory = SAXParserFactory.newInstance();
	         SAXParser saxParser = factory.newSAXParser();
	         XMLHandler xmlhandler = new XMLHandler();
	         saxParser.parse(inputFileA1, xmlhandler);     
	      } catch (Exception e) {
	         e.printStackTrace();
	      }

	}

}
class XMLHandler extends DefaultHandler {

	  

	   @Override
	   public void startElement(String uri, 
	      String localName, String qName, Attributes attributes)
	         throws SAXException {
		   System.out.println();
		   //System.out.println("Start Element   :      "+"qname  "+qName+"     attribute length "+attributes.getLength());
	       int attributeLength=attributes.getLength();	       
		   if(attributeLength>0)
	       {
			   for(int i=0;i<=attributeLength;i++)
			   {	    	   
	    	    System.out.println(attributes.getQName(i));	    	   
	    	   System.out.println(attributes.getValue(i));
			   }
	    	   
	       }
		   System.out.println();System.out.println();
		   
	   }

	   @Override
	   public void endElement(String uri, 
	      String localName, String qName) throws SAXException {
		  // System.out.println();
		   System.out.println(qName);
		      
	      
	   }

	   @Override
	   public void characters(char ch[], 
	      int start, int length) throws SAXException {
		   System.out.println();
		   System.out.println(new String(ch,start,length));
		   System.out.println();
		 
	   }
	}

package xml;

import java.io.File;
import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

import javax.xml.parsers.*;

import org.w3c.dom.*;
import org.xml.sax.SAXException;

import dao.DataBase_Connection;



public class DOM_Parser  {
	
	private Statement smtInstance=null;
	//private Student_Pojo studentObj;
	private String xmlFileName;
	private DataBase_Connection daoInstance;
	private Connection conInstance;
	private String ConfigFileName;	
	
	
	public String getConfigFileName() {
		return ConfigFileName;
	}
	public void setConfigFileName(String configFileName) {
		ConfigFileName = configFileName;
	}
	public String getXmlFileName() {
		return xmlFileName;
	}
	public void setXmlFileName(String xmlFileName) {
		this.xmlFileName = xmlFileName;
	}
	public DOM_Parser() {
		//DataBase_Connection.setConfigFileName(ConfigFileName);
		//this.conInstance=DataBase_Connection.getConnectionInstance();
	}
	public DOM_Parser(String ProgramConfigFileName) {
		//DataBase_Connection.setConfigFileName(ConfigFileName);
		//this.conInstance=DataBase_Connection.getConnectionInstance();
		
	}
	public void parseDocument(String fileName)
	{
		File fXmlFile = new File(fileName);
		DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
		DocumentBuilder dBuilder;
		try {
			dBuilder = dbFactory.newDocumentBuilder();
			
			Document doc = dBuilder.parse(fXmlFile);
			//printElements(doc);
			
		   NodeList nl=doc.getElementsByTagName("measType");
		   System.out.println(nl.getLength());
		   for(int i=0;i<nl.getLength();i++)
		   {
			  Node node= nl.item(i);			  
			  System.out.println(node.getNodeName()  );
			  if(node.hasAttributes())
			  {
				  System.out.println(node.hasChildNodes()+""+node.hasAttributes());
				System.out.println();
				 
			  }
			  System.out.println(node.getNodeValue());
		   }
			
		} catch (ParserConfigurationException | SAXException | IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
				
	}
	
		 	
	public static void main(String[] args) throws SQLException {
		//DataBase_Connection.setConfigFileName("DBconfig.properties");
		DOM_Parser dom=new DOM_Parser();
		dom.setXmlFileName("student.xml");
		//dom.readxml();
		dom.parseDocument("./xml test files/A2.TS32.435.v11.0.0.xml");
		
		DataBase_Connection.closeConnection();
	}

}

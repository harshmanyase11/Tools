package pojo;


public class MEAS_VALUES {
	private String beginTime;
    private int jobid;
    private String measObjLdn;
    private String measType;
    private String measResult;

    
    
    
	/**
	 * @return the beginTime
	 */
	public String getBeginTime() {
		return beginTime;
	}



	/**
	 * @param beginTime the beginTime to set
	 */
	public void setBeginTime(String beginTime) {
		this.beginTime = beginTime;
	}



	/**
	 * @return the jobid
	 */
	public int getJobid() {
		return jobid;
	}



	/**
	 * @param jobid the jobid to set
	 */
	public void setJobid(int jobid) {
		this.jobid = jobid;
	}



	/**
	 * @return the measObjLdn
	 */
	public String getMeasObjLdn() {
		return measObjLdn;
	}



	/**
	 * @param measObjLdn the measObjLdn to set
	 */
	public void setMeasObjLdn(String measObjLdn) {
		this.measObjLdn = measObjLdn;
	}



	/**
	 * @return the measType
	 */
	public String getMeasType() {
		return measType;
	}



	/**
	 * @param measType the measType to set
	 */
	public void setMeasType(String measType) {
		this.measType = measType;
	}



	/**
	 * @return the measResult
	 */
	public String getMeasResult() {
		return measResult;
	}



	/**
	 * @param measResult the measResult to set
	 */
	public void setMeasResult(String measResult) {
		this.measResult = measResult;
	}



	@Override
	public String toString() {
		return "MEAS_VALUES [jobid=" + jobid + ", measObjLdn=" + measObjLdn
				+ ", measType=" + measType + ", measResult=" + measResult + "]";
	}
    
    
}

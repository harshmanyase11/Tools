/**
 * 
 */
package pojo;


public class MEAS_HEADER {

	private String beginTime;
	private String FileFormatVersion ;
	private String VendorName ;
	private String DnPrefix;
	private String LocalDn ;
	private String ElementType;
	private String EndTime;
	/**
	 * @return the beginTime
	 */
	public String getBeginTime() {
		return beginTime;
	}
	/**
	 * @param beginTime the beginTime to set
	 */
	public void setBeginTime(String beginTime) {
		this.beginTime = beginTime;
	}
	/**
	 * @return the fileFormatVersion
	 */
	public String getFileFormatVersion() {
		return FileFormatVersion;
	}
	/**
	 * @param fileFormatVersion the fileFormatVersion to set
	 */
	public void setFileFormatVersion(String fileFormatVersion) {
		FileFormatVersion = fileFormatVersion;
	}
	/**
	 * @return the vendorName
	 */
	public String getVendorName() {
		return VendorName;
	}
	/**
	 * @param vendorName the vendorName to set
	 */
	public void setVendorName(String vendorName) {
		VendorName = vendorName;
	}
	/**
	 * @return the dnPrefix
	 */
	public String getDnPrefix() {
		return DnPrefix;
	}
	/**
	 * @param dnPrefix the dnPrefix to set
	 */
	public void setDnPrefix(String dnPrefix) {
		DnPrefix = dnPrefix;
	}
	/**
	 * @return the localDn
	 */
	public String getLocalDn() {
		return LocalDn;
	}
	/**
	 * @param localDn the localDn to set
	 */
	public void setLocalDn(String localDn) {
		LocalDn = localDn;
	}
	/**
	 * @return the elementType
	 */
	public String getElementType() {
		return ElementType;
	}
	/**
	 * @param elementType the elementType to set
	 */
	public void setElementType(String elementType) {
		ElementType = elementType;
	}
	/**
	 * @return the endTime
	 */
	public String getEndTime() {
		return EndTime;
	}
	/**
	 * @param endTime the endTime to set
	 */
	public void setEndTime(String endTime) {
		EndTime = endTime;
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "MEAS_HEADER [beginTime=" + beginTime + ", FileFormatVersion="
				+ FileFormatVersion + ", VendorName=" + VendorName
				+ ", DnPrefix=" + DnPrefix + ", LocalDn=" + LocalDn
				+ ", ElementType=" + ElementType + ", EndTime=" + EndTime + "]";
	}
	
	
}

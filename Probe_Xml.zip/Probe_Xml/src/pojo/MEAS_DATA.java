package pojo;

public class MEAS_DATA {
	
	private String beginTime;
	private String jobId;
	private String granPeriodDuration;
	private String granPeriodEndTime ;
	private String repPeriodDuration;
	private String managedElemnt_LocalDn;
	private String managedElemnt_UserLabel;
	private String ManagedElemnt_SW_Version;
	/**
	 * @return the beginTime
	 */
	public String getBeginTime() {
		return beginTime;
	}
	/**
	 * @param beginTime the beginTime to set
	 */
	public void setBeginTime(String beginTime) {
		this.beginTime = beginTime;
	}
	/**
	 * @return the jobId
	 */
	public String getJobId() {
		return jobId;
	}
	/**
	 * @param jobId the jobId to set
	 */
	public void setJobId(String jobId) {
		this.jobId = jobId;
	}
	/**
	 * @return the granPeriodDuration
	 */
	public String getGranPeriodDuration() {
		return granPeriodDuration;
	}
	/**
	 * @param granPeriodDuration the granPeriodDuration to set
	 */
	public void setGranPeriodDuration(String granPeriodDuration) {
		this.granPeriodDuration = granPeriodDuration;
	}
	/**
	 * @return the granPeriodEndTime
	 */
	public String getGranPeriodEndTime() {
		return granPeriodEndTime;
	}
	/**
	 * @param granPeriodEndTime the granPeriodEndTime to set
	 */
	public void setGranPeriodEndTime(String granPeriodEndTime) {
		this.granPeriodEndTime = granPeriodEndTime;
	}
	/**
	 * @return the repPeriodDuration
	 */
	public String getRepPeriodDuration() {
		return repPeriodDuration;
	}
	/**
	 * @param repPeriodDuration the repPeriodDuration to set
	 */
	public void setRepPeriodDuration(String repPeriodDuration) {
		this.repPeriodDuration = repPeriodDuration;
	}
	/**
	 * @return the managedElemnt_LocalDn
	 */
	public String getManagedElemnt_LocalDn() {
		return managedElemnt_LocalDn;
	}
	/**
	 * @param managedElemnt_LocalDn the managedElemnt_LocalDn to set
	 */
	public void setManagedElemnt_LocalDn(String managedElemnt_LocalDn) {
		this.managedElemnt_LocalDn = managedElemnt_LocalDn;
	}
	/**
	 * @return the managedElemnt_UserLabel
	 */
	public String getManagedElemnt_UserLabel() {
		return managedElemnt_UserLabel;
	}
	/**
	 * @param managedElemnt_UserLabel the managedElemnt_UserLabel to set
	 */
	public void setManagedElemnt_UserLabel(String managedElemnt_UserLabel) {
		this.managedElemnt_UserLabel = managedElemnt_UserLabel;
	}
	/**
	 * @return the managedElemnt_SW_Version
	 */
	public String getManagedElemnt_SW_Version() {
		return ManagedElemnt_SW_Version;
	}
	/**
	 * @param managedElemnt_SW_Version the managedElemnt_SW_Version to set
	 */
	public void setManagedElemnt_SW_Version(String managedElemnt_SW_Version) {
		ManagedElemnt_SW_Version = managedElemnt_SW_Version;
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "MEAS_DATA [beginTime=" + beginTime + ", jobId=" + jobId
				+ ", granPeriodDuration=" + granPeriodDuration
				+ ", granPeriodEndTime=" + granPeriodEndTime
				+ ", repPeriodDuration=" + repPeriodDuration
				+ ", managedElemnt_LocalDn=" + managedElemnt_LocalDn
				+ ", managedElemnt_UserLabel=" + managedElemnt_UserLabel
				+ ", ManagedElemnt_SW_Version=" + ManagedElemnt_SW_Version
				+ "]";
	}
	
	

}

package logger;

import java.io.IOException;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.apache.log4j.PatternLayout;
import org.apache.log4j.varia.LevelRangeFilter;

import sp_Logger.Log_ConsoleAppender;
import sp_Logger.RollingFileAppender;



public class LogHandler {

	public static Logger xmlParserLogger=Logger.getLogger(LogHandler.class.getName());
	
	
	/**
	 * @return the xmlParserLogger
	 */
	public static Logger getXmlParserLogger() {
		return xmlParserLogger;
	}
	public Log_ConsoleAppender consoleAppender()
	{
		Log_ConsoleAppender con=new Log_ConsoleAppender();
		con.setName("console");
		con.setTarget("System.out");
		con.setLayout(new PatternLayout(" %d{yyyy-MM-dd HH:mm:ss.SS} - %5p - [%t] - (%F:%L) - %m%n"));
		con.activateOptions();
		return con;
	}
	public RollingFileAppender rollingAppender() throws IOException {

		RollingFileAppender rollInstance = new RollingFileAppender();
		rollInstance.setName("XML Parser ");
		rollInstance.setMaxFileSize("10MB");
		rollInstance.setLayout(new PatternLayout("%d{yyyy-MM-dd HH:mm:ss.SS} - %5p - [%t] - (%F:%L) - %m%n"));
		rollInstance.setFile("Xml_Paser_");
		rollInstance.setMaxBackupIndex(1);
		/*LevelRangeFilter filter = new LevelRangeFilter();
		filter.setLevelMax(Level.INFO);
		filter.setLevelMin(Level.DEBUG);
		rollInstance.addFilter(filter);*/
		rollInstance.activateOperation();
		return rollInstance;
	}
	
	public LogHandler() {
		// TODO Auto-generated constructor stub
		try {
			xmlParserLogger.addAppender(rollingAppender());
			xmlParserLogger.addAppender(consoleAppender());
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			
		}
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		LogHandler dh=new LogHandler();
     xmlParserLogger.info("Logger started ");
	}

}

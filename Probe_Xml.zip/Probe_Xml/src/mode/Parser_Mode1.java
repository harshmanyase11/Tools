package mode;

import java.io.File;
import java.sql.Connection;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Set;
import java.util.StringTokenizer;

import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import logger.LogHandler;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

import pojo.MEAS_DATA;
import pojo.MEAS_HEADER;
import pojo.MEAS_VALUES;
import dao.DataBase_Connection;
import dbhandler.DatabaseHandler;

public class Parser_Mode1 extends DefaultHandler {

	String currentTagName;
	String inputXmlFileName;
	public LinkedHashMap<String, ArrayList<String>> measValues;
	public LinkedHashMap<String, LinkedHashMap<String, String>> measDATA;

	/**
	 * @return the fileName
	 */
	public String getFileName() {
		return inputXmlFileName;
	}

	/**
	 * @param fileName
	 *            the fileName to set
	 */
	public void setFileName(String fileName) {
		this.inputXmlFileName = fileName;
	}

	public Parser_Mode1() {
		// studentObj=new Student_Pojo();
		// this.conInstance=DataBase_Connection.getConnectionInstance();

		measValues = new LinkedHashMap<String, ArrayList<String>>();
		measValues.clear();
		measDATA = new LinkedHashMap<String, LinkedHashMap<String, String>>();
	}

	@Override
	public void startElement(String uri, String localName, String qName,
			Attributes attributes) throws SAXException {
		currentTagName = qName;

		for (int i = 0; i < attributes.getLength(); i++) {
			String aname = attributes.getQName(i);
			String value = attributes.getValue(i);
			// System.out.println("  att "+aname+"   "+"="+value);
			addValues(measDATA, qName, aname, value);
			addValues(aname, value);
			// measDATA.put(qName, );

		}

	}

	@Override
	public void endElement(String uri, String localName, String qName)
			throws SAXException {

		// System.out.println("End Element :" + qName);

	}

	@Override
	public void characters(char ch[], int start, int length)
			throws SAXException {
		String value = String.copyValueOf(ch, start, length).trim();

		switch (currentTagName) {
		case "measTypes":
			// xml_Data.putIfAbsent("measTypes", value);
			if (!value.isEmpty())
				addValues("measTypes", value);
			// System.out.println("meas Types "+value);
			break;
		case "measResults":
			// xml_Data.putIfAbsent("measResults", value);
			if (!value.isEmpty())
				addValues("measResults", value);
			// System.out.println("meas Result :"+value);
			break;
		case "suspect":
			if (!value.isEmpty())
				addValues("suspect", value);
			// xml_Data.putIfAbsent("suspect", value);
			break;
		case "r":
			if (!value.isEmpty())
				addValues("r", value);
			// addValues(measDATA, currentTagName, aname, value);
			// xml_Data.putIfAbsent("suspect", value);
			break;

		}

	}

	private void addValues(String key, String value) {
		ArrayList<String> tempList = null;
		if (measValues.containsKey(key)) {
			tempList = measValues.get(key);
			if (tempList == null)
				tempList = new ArrayList<String>();
			tempList.add(value);
		} else {
			tempList = new ArrayList<String>();
			tempList.add(value);
		}
		measValues.put(key, tempList);
	}

	private void addValues(
			LinkedHashMap<String, LinkedHashMap<String, String>> mapOBJ,
			String key, String key2, String value) {
		LinkedHashMap<String, String> tempList = null;
		if (mapOBJ.containsKey(key)) {
			tempList = mapOBJ.get(key);
			if (tempList == null)
				tempList = new LinkedHashMap<String, String>();
			tempList.put(key2, value);
		} else {
			tempList = new LinkedHashMap<String, String>();
			tempList.put(key2, value);
		}
		mapOBJ.put(key, tempList);
	}

	public void printMap(
			LinkedHashMap<String, LinkedHashMap<String, String>> mapOBJ) {
		System.out.println("---meas value ---");
		Iterator<String> it = mapOBJ.keySet().iterator();
		LinkedHashMap<String, String> tempList = null;
		while (it.hasNext()) {
			String key = it.next().toString();
			tempList = mapOBJ.get(key);
			if (tempList != null) {
				Iterator<String> it2 = tempList.keySet().iterator();

				while (it2.hasNext()) {
					String key2 = it2.next().toString();
					String values = tempList.get(key2);
					System.out.printf(" Key1 : " + key + " ,  key2  : " + key2
							+ "  Value : " + values);
					System.out.println();
				}

			}
		}

	}

	public void printMeasValues() {
		System.out.println("---meas value ---");
		Iterator<String> it = measValues.keySet().iterator();
		ArrayList<String> tempList = null;

		while (it.hasNext()) {
			String key = it.next().toString();
			tempList = measValues.get(key);
			if (tempList != null) {
				for (String value : tempList) {
					System.out.println("Key : " + key + " , Value : " + value);
				}
			}
		}

		// System.out.println( "test  :"+measValues.get("localDn"));
	}

	public ArrayList<String> StringTokenizer(String input, String delimeter) {
		ArrayList<String> temp = new ArrayList<String>();
		StringTokenizer st = new StringTokenizer(input, delimeter);
		while (st.hasMoreTokens()) {
			String value = st.nextToken();
			// System.out.println(value);
			temp.add(value);
		}
		return temp;
	}

	public void printArrayList(ArrayList<String> arraylist) {
		System.out.println("----------------------------");
		for (String string : arraylist) {
			System.out.println(string);
		}
	}

	public void getHeaderValues() {
		MEAS_HEADER header = new MEAS_HEADER();
		header.setBeginTime(measValues.get("beginTime").get(0));
		header.setFileFormatVersion(measValues.get("fileFormatVersion").get(0));
		header.setVendorName(measValues.get("vendorName").get(0));
		header.setDnPrefix(measValues.get("dnPrefix").get(0));
		header.setElementType(measValues.get("elementType").get(0));
		header.setLocalDn(measValues.get("localDn").get(0));
	  DatabaseHandler db=new DatabaseHandler();
	  db.save3GPP_MEAS_HEADER(header);
	}
     
	public void getMeasDataValues()
	{
		MEAS_DATA data=new MEAS_DATA();
		data.setBeginTime(measValues.get("beginTime").get(0));
		data.setGranPeriodDuration(measValues.get("duration").get(0));
		data.setGranPeriodEndTime(measValues.get("endTime").get(0));
		data.setJobId(measValues.get("jobId").get(0));
		data.setManagedElemnt_LocalDn(measValues.get("localDn").get(1));
		if(measValues.containsKey("swVersion"))
		data.setManagedElemnt_SW_Version(measValues.get("swVersion").get(0));
		data.setManagedElemnt_UserLabel(measValues.get("userLabel").get(0));
		data.setRepPeriodDuration(measValues.get("duration").get(0));
		DatabaseHandler db=new DatabaseHandler();
		db.save3GPP_MEAS_DATA(data);
	}
	public void getMeasResultValues() {
		ArrayList<String> measTypeList = new ArrayList<String>();
		//ArrayList<String> measObjLdn = new ArrayList<String>();
		ArrayList<String> measResultList = new ArrayList<String>();
		//measObjLdn = StringTokenizer(measValues.get("measObjLdn").get(0)," ");
		measTypeList = StringTokenizer(measValues.get("measTypes").get(0), " ");
		MEAS_VALUES val=new MEAS_VALUES();
		DatabaseHandler db=new DatabaseHandler();
		val.setBeginTime(measValues.get("beginTime").get(0));
		val.setJobid(Integer.parseInt(measValues.get("jobId").get(0)));
		
		
		for(int i=0;i<measValues.get("measObjLdn").size();i++)
		{
			String measObjLdn = measValues.get("measObjLdn").get(i);
			measTypeList = StringTokenizer(measValues.get("measTypes").get(0), " ");
			measResultList=StringTokenizer(measValues.get("measResults").get(i)," ");
			for(int j=0;j<measTypeList.size();j++)
			{
				val.setMeasObjLdn(measObjLdn);
				val.setMeasType(measTypeList.get(j));
				val.setMeasResult(measResultList.get(j));
				db.save3GPP_MEAS_Values(val);
			}
		}
	}

	public void saveData() {
		getHeaderValues();
		getMeasDataValues();
         getMeasResultValues();
	}
	
	public void parse()
	{
		try {
			// DataBase_Connection.setConfigFileName("DBconfig.properties");
			new LogHandler();// Logger is configured
			LogHandler.xmlParserLogger.info("logger is started");
			//String fileName = "./xml test files/A2.TS32.435.v11.0.0.xml";
			File inputFile = new File(inputXmlFileName);
			LogHandler.xmlParserLogger.info("Parsed file Name is :" + inputXmlFileName);
			SAXParserFactory factory = SAXParserFactory.newInstance();
			SAXParser saxParser = factory.newSAXParser();
			Parser_Mode1 obj = new Parser_Mode1();
			saxParser.parse(inputFile, obj);
			//obj.printMeasValues();
			// obj.printMap(obj.measDATA);
			 obj.saveData();
			DataBase_Connection.closeConnection();
			Parser_Mode1 o = new Parser_Mode1();
			saxParser.parse(inputFile, o);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static void main(String[] args) {
		try {
			// DataBase_Connection.setConfigFileName("DBconfig.properties");
			new LogHandler();// Logger is configured
			LogHandler.xmlParserLogger.info("logger is started");
			String fileName = "./xml test files/A2.TS32.435.v11.0.0.xml";
			File inputFile = new File(fileName);
			LogHandler.xmlParserLogger.info("Parsed file Name is :" + fileName);
			SAXParserFactory factory = SAXParserFactory.newInstance();
			SAXParser saxParser = factory.newSAXParser();
			Parser_Mode1 obj = new Parser_Mode1();
			saxParser.parse(inputFile, obj);
			obj.printMeasValues();
			 obj.printMap(obj.measDATA);
			 obj.saveData();
			DataBase_Connection.closeConnection();
			Parser_Mode1 objInstance = new Parser_Mode1();
			saxParser.parse(inputFile, objInstance);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}

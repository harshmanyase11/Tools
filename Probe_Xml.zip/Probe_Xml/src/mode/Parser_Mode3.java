package mode;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.StringTokenizer;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

public class Parser_Mode3 {

	private String inputXmlFileName;
	private LinkedHashMap<String, ArrayList<String>> measValues;
	
	
	/**
	 * @return the inputXmlFileName
	 */
	public String getInputXmlFileName() {
		return inputXmlFileName;
	}
	/**
	 * @param inputXmlFileName the inputXmlFileName to set
	 */
	public void setInputXmlFileName(String inputXmlFileName) {
		this.inputXmlFileName = inputXmlFileName;
	}
	
	public Parser_Mode3() {
		this.measValues = new LinkedHashMap<String, ArrayList<String>>();
		this.measValues.clear();
		
	}
	public void parseDocument()
	{
		File fXmlFile = new File(getInputXmlFileName());
		DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
		DocumentBuilder dBuilder;
		try {
			dBuilder = dbFactory.newDocumentBuilder();
			Document doc = dBuilder.parse(fXmlFile);
			//printElements(doc);
		    parsexml();
			//getAll(doc);
			
		} catch (ParserConfigurationException | SAXException | IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
				
	}
	
	
	public void getAll(Document doc)
	{
		NodeList nl = doc.getElementsByTagName("*");
		   Element e;
		   Node n;
		   NamedNodeMap nnm;
		   String attributeName;
		   String attributeValue;		   
		   int i, len;		 
		   len = nl.getLength();
		   for (int j=0; j < len; j++)
		   {
		      e = (Element)nl.item(j);
		      e.getTagName();
		      e.getTextContent();
		    //  System.out.println(currentTagName + ":"+currentTagValue);
		      nnm = e.getAttributes();
		  
		      if (nnm != null)
		      {
		         for (i=0; i<nnm.getLength(); i++)
		         {
		            n = nnm.item(i);
		            attributeName = n.getNodeName();
		            attributeValue = n.getNodeValue();
		            System.out.println("att   "+attributeName+"  val    "+attributeValue);
		           // addValues(attributeName, attributeValue);
		         }
		      }
		   }
	}
	//to parse xml file of A3 type
	public void parsexml()
	{
		String jobId = null;
        String granPeriodDuration;
        String granPeriodEndTime;
        String repPeriodDuration;
        String  measObjLdn;
        String measTypes;
        String measResults;
        ArrayList<String> measTypeList=null;
        ArrayList<String> measResultList = null;
		try {	
	         File inputFile = new File(getInputXmlFileName());
	         DocumentBuilderFactory dbFactory 
	            = DocumentBuilderFactory.newInstance();
	         DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
	         Document doc = dBuilder.parse(inputFile);
	         doc.getDocumentElement().normalize();
	         System.out.println("Root element :" + doc.getDocumentElement().getNodeName());
	         
	         NodeList nList = doc.getElementsByTagName("measInfo");
	         for (int temp = 0; temp < nList.getLength(); temp++) {
	            Node nNode = nList.item(temp);
	            
	            System.out.println("\nCurrent Element :"  + nNode.getNodeName());
	            if (nNode.getNodeType() == Node.ELEMENT_NODE) {
	               Element eElement = (Element) nNode;
	               System.out.println("measInfoId : " + eElement.getAttribute("measInfoId"));
	               System.out.println("--------------------------");
	                    
	               
	               NodeList children = nNode.getChildNodes();
	               if (children != null) {
	                   for (int i = 0, n = children.getLength(); i < n; i++) {
	                       Node child = children.item(i);
	                       if(child.getNodeType()==Node.ELEMENT_NODE)
	                       {
	                         Element eElement2=(Element) child;
	                        
	                         measTypeList=new ArrayList<String>();
	                         measResultList=new ArrayList<String>();
	                         
	                         jobId=eElement2.getAttribute("jobId");
	                         if(child.getNodeName().equals("granPeriod"))
	                         granPeriodDuration=eElement2.getAttribute("duration");
	                         granPeriodEndTime=eElement2.getAttribute("endTime");
	                         if(child.getNodeName().equals("repPeriod"))
	                         repPeriodDuration=eElement2.getAttribute("duration");
	                         measObjLdn=eElement2.getAttribute("measObjLdn");
	                         
	                         measTypes=eElement.getElementsByTagName("measTypes").item(0).getTextContent();
	                         System.out.println("meas type ---------------"+measTypes);
	                         if(measTypes!=null)
	                         measTypeList=StringTokenizer(measTypes, " ");
	                        
	                         
	                         measResults=eElement.getElementsByTagName("measResults").item(0).getTextContent();
	                         System.out.println("meas result +++++++++++++++++"+measResults);
	                         if(measResults!=null)
	                         measResultList=StringTokenizer(measResults, " ");
	                         
	                         
	                         
	                         if(jobId!=null)
	      	                 System.out.println("job id : " + jobId);

	                       }
	                       
	                    
	                   }
	                   
	               }
	     
	            }
	            
	         }
	         
	      } catch (Exception e) {
	         e.printStackTrace();
	      }
		printArrayList(measResultList);
        printArrayList(measTypeList);
	}
	
	private void addValues(String key, String value) {
		ArrayList<String> tempList = null;
		if (this.measValues.containsKey(key)) {
			tempList = this.measValues.get(key);
			if (tempList == null)
				tempList = new ArrayList<String>();
			tempList.add(value);
		} else {
			tempList = new ArrayList<String>();
			tempList.add(value);
		}
		this.measValues.put(key, tempList);
	}
	

	public void printMeasValues() {
		System.out.println("---meas value ---");
		Iterator<String> it = this.measValues.keySet().iterator();
		ArrayList<String> tempList = null;

		while (it.hasNext()) {
			String key = it.next().toString();
			tempList = this.measValues.get(key);
			if (tempList != null) {
				for (String value : tempList) {
					System.out.println("Key : " + key + " , Value : " + value);
				}
			}
		}
	}
	/*   To tokenize the string values by delimeter*/
	public ArrayList<String> StringTokenizer(String input, String delimeter) {
		ArrayList<String> temp = new ArrayList<String>();
		StringTokenizer st = new StringTokenizer(input, delimeter);
		while (st.hasMoreTokens()) {
			String value = st.nextToken();
			// System.out.println(value);
			temp.add(value);
		}
		return temp;
	}
	
	// To print arraylist values 
	public void printArrayList(ArrayList<String> arraylist) {
		System.out.println("----------------------------");
		for (String string : arraylist) {
			System.out.println(string);
		}
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Parser_Mode3 mode3=new Parser_Mode3();
		mode3.setInputXmlFileName("./xml test files/A3.TS32.435.v11.0.0.xml");
		mode3.parseDocument();

	}

}

package mode;

import java.io.File;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Set;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import logger.LogHandler;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import dbhandler.DatabaseHandler;
import pojo.MEAS_DATA;
import pojo.MEAS_HEADER;
import pojo.MEAS_VALUES;
public class Parser_Mode2 {

	public String inputFileName;
	private LinkedHashMap<String, String> measType;
	private LinkedHashMap<String, ArrayList<String>> measValues;
	private LinkedHashMap<String, ArrayList<String>> measResults;
	
	/**
	 * @return the inputFileName
	 */
	public String getInputFileName() {
		return inputFileName;
	}
	/**
	 * @param inputFileName the inputFileName to set
	 */
	public void setInputFileName(String inputFileName) {
		this.inputFileName = inputFileName;
	}
	
	public Parser_Mode2() {
		measValues = new LinkedHashMap<String, ArrayList<String>>();
		measValues.clear();
		measType = new LinkedHashMap<String, String>();
		measType.clear();
		measResults = new LinkedHashMap<String, ArrayList<String>>();
		measResults.clear();
	}
	

	public void parse()
	{
		LogHandler.getXmlParserLogger().info("Parsing is Started");
		try{
			String endTime=null;
		File inputFile = new File(inputFileName);
        DocumentBuilderFactory dbFactory 
           = DocumentBuilderFactory.newInstance();
        DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
        Document doc = dBuilder.parse(inputFile);
        doc.getDocumentElement().normalize();
        
        //To get The Value Of end Time
        NodeList nList = doc.getElementsByTagName("measCollec");
        //System.out.println("----------------------------");
        for (int temp = 0; temp < nList.getLength(); temp++) {
           Node nNode = nList.item(temp);
         //  System.out.println("\nCurrent Element :"  + nNode.getNodeName());
           if (nNode.getNodeType() == Node.ELEMENT_NODE) {
              Element eElement = (Element) nNode;
              System.out.println("endTime : " + eElement.getAttribute("endTime"));
              endTime=eElement.getAttribute("endTime");
           }
        }
        
        
        
        
		NodeList nl = doc.getElementsByTagName("*");
		   Element e;
		   Node n;
		   NamedNodeMap nnm;
		   String currentTagName;
		   String currentTagValue;
		   String attributeName;
		   String attributeValue;
		   String measObjLdn = "";
		   DatabaseHandler DBinstance=new DatabaseHandler();
		   
		   
		   int i, len;
		 
		   len = nl.getLength();

		   for (int j=0; j < len; j++)
		   {
		      e = (Element)nl.item(j);
		      currentTagName=e.getTagName();
		      currentTagValue=e.getTextContent();
		    //  System.out.println(currentTagName + ":"+currentTagValue);
		      nnm = e.getAttributes();
		  
		      if (nnm != null)
		      {
		         for (i=0; i<nnm.getLength(); i++)
		         {
		            n = nnm.item(i);
		            attributeName = n.getNodeName();
		            attributeValue = n.getNodeValue();
		          // System.out.print(" " + attrname + " = " + attrval);
		            addValues(attributeName, attributeValue);
		            
		            switch (currentTagName) {	

		            case "job":
		            	MEAS_HEADER header=new MEAS_HEADER();
		            	header.setBeginTime(this.measValues.get("beginTime").get(0));
		            	header.setDnPrefix(this.measValues.get("localDn").get(0));
		            	header.setFileFormatVersion(this.measValues.get("fileFormatVersion").get(0));
		            	header.setElementType(this.measValues.get("elementType").get(0));
		            	header.setEndTime(endTime);
		            	header.setLocalDn(this.measValues.get("localDn").get(0));
		            	header.setVendorName(this.measValues.get("vendorName").get(0));
						System.out.println(header.toString());
		            	DBinstance.save3GPP_MEAS_HEADER(header);
						
						break;
					
					case "granPeriod":
						
						break;
					case "repPeriod":
						MEAS_DATA measData=new MEAS_DATA();
						measData.setBeginTime(this.measValues.get("beginTime").get(0));
						measData.setGranPeriodDuration(this.measValues.get("duration").get(0));
						measData.setGranPeriodEndTime(this.measValues.get("endTime").get(0));
						measData.setRepPeriodDuration(this.measValues.get("duration").get(1));
						measData.setJobId(this.measValues.get("jobId").get(0));
						measData.setManagedElemnt_LocalDn(measValues.get("localDn").get(1));
						if(measValues.containsKey("swVersion"))
						measData.setManagedElemnt_SW_Version(measValues.get("swVersion").get(0));
						else
						measData.setManagedElemnt_SW_Version("");
						measData.setManagedElemnt_UserLabel(measValues.get("userLabel").get(0));
						System.out.println(measData.toString());
						DBinstance.save3GPP_MEAS_DATA(measData);
						
						break;
						
	
					case "measType":
						         this.measType.put(attributeValue, currentTagValue);
						break;
					case "measValue":
						          
						          if(attributeName.equals("measObjLdn"))
						        	 measObjLdn=attributeValue;						
						break;
					case "r":
						
						MEAS_VALUES measvalue=new MEAS_VALUES();
						measvalue.setBeginTime(this.measValues.get("beginTime").get(0));
						measvalue.setJobid(Integer.parseInt(this.measValues.get("jobId").get(0)));
						measvalue.setMeasObjLdn(measObjLdn);
						measvalue.setMeasResult(currentTagValue);
						measvalue.setMeasType(this.measType.get(attributeValue));
						System.out.println("meas value obj :"+measvalue.toString());
						DBinstance.save3GPP_MEAS_Values(measvalue);
						
						
						break;
					default:
						break;
					}
		            
		         }
		         
		      }
		      System.out.println();
		   }}
		   catch (Exception e2) {
			// TODO: handle exception
		}
		
	}
	private void addValues(String key, String value) {
		ArrayList<String> tempList = null;
		if (this.measValues.containsKey(key)) {
			tempList = this.measValues.get(key);
			if (tempList == null)
				tempList = new ArrayList<String>();
			tempList.add(value);
		} else {
			tempList = new ArrayList<String>();
			tempList.add(value);
		}
		this.measValues.put(key, tempList);
	}
	private void addResult(String key, String value) {
		ArrayList<String> tempList = null;
		if (this.measResults.containsKey(key)) {
			tempList = this.measResults.get(key);
			if (tempList == null)
				tempList = new ArrayList<String>();
			tempList.add(value);
		} else {
			tempList = new ArrayList<String>();
			tempList.add(value);
		}
		this.measResults.put(key, tempList);
	}

	public void printMeasValues() {
		System.out.println("---meas value ---");
		Iterator<String> it = this.measValues.keySet().iterator();
		ArrayList<String> tempList = null;

		while (it.hasNext()) {
			String key = it.next().toString();
			tempList = this.measValues.get(key);
			if (tempList != null) {
				for (String value : tempList) {
					System.out.println("Key : " + key + " , Value : " + value);
				}
			}
		}
	}
	public void printMeasResult() {
		System.out.println("---meas Result ---");
		Iterator<String> it = measResults.keySet().iterator();
		ArrayList<String> tempList = null;

		while (it.hasNext()) {
			String key = it.next().toString();
			tempList = measResults.get(key);
			if (tempList != null) {
				for (String value : tempList) {
					System.out.println("Key : " + key + " , Value : " + value);
				}
			}
		}
	}
	public void printMeasType() {
		Set<String> set = measType.keySet();
		System.out.println("-------------------");
		System.out.println("key      " + "     Values");
		for (String key : set) {
			String value = measType.get(key);
			System.out.println(key + " " + value);
		}
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new LogHandler();
     Parser_Mode2 mode2=new Parser_Mode2();
     mode2.setInputFileName("./xml test files/A2.TS32.435.v11.0.0.xml");
     mode2.parse();
     mode2.printMeasValues();
     mode2.printMeasType();
	}

}

package com.main;

import java.io.*;
import java.net.*;
import java.util.logging.Logger;

import oracle.jdbc.driver.DBConversion;

import com.Dao.Probe_DB_Connection;
import com.Dao.SPprobe_DAO;
import com.logger.SPProbe_Logger;
import com.pojos.SPProbe_ERROR;
import com.pojos.SPprobe_REQ;
import com.pojos.SS7Message_IP;
import com.pojos.SS7Message_M2PA;
import com.pojos.SS7Message_M3UA;
import com.utils.FileUtils;
public class UserApp {
public UserApp() {
	
}

	public void execute() throws Exception {
		SPProbe_Logger.logger.info("In User app");
		Socket socketInstance = new Socket("localhost", 1234);
		ObjectOutputStream outputStream = new ObjectOutputStream(socketInstance.getOutputStream());

		SPprobe_REQ request = new SPprobe_REQ();SPProbe_Logger.logger.info("SPProbe_REQ initiated");
		request.setRequestType("Register");
		request.setMessageType("ISUP");
		request.setMessageFormat("SPPROBE_MSG_M3UA_MSG");
		request.setIpAddress("localhost");
		request.setPort(2345);
		request.setSio("sio");
		outputStream.writeObject(request);
		socketInstance.close();

		// Server starts here
		ServerSocket userAppServerSocket = new ServerSocket(request.getPort());

		Socket appServerSocketInstance = userAppServerSocket.accept();
		UserAppServerThread thread = new UserAppServerThread(appServerSocketInstance, request);

		thread.join();
	}

	public static void main(String[] args) {

	  SPProbe_Logger.setLogger();
	  Logger logger=Logger.getLogger(UserApp.class.getName());
	  SPProbe_Logger.logger.info("USER APP Started");
	 Probe_DB_Connection.setConfigFile("DBconfig.properties");
	 Probe_DB_Connection.getConnectionInstance();
	  //SPprobe_DAO.setConfiguration_FIle_Name("DBconfig.properties");
	 // SPprobe_DAO.getConnectionInstance();
		UserApp clientInstance = new UserApp();
		try {
			clientInstance.execute();
		} catch (Exception e) {

			e.printStackTrace();
		}
	}

	private class UserAppServerThread extends Thread {

		Socket appServerSocketInstance;
		SPprobe_REQ request;

		public UserAppServerThread(Socket appServerSocketInstance,SPprobe_REQ request) {
			this.appServerSocketInstance = appServerSocketInstance;
			this.request = request;
			SPProbe_Logger.logger.info("Running thread name  : "+this.getName());
			
			System.out.println("Thread name  :"+this.getName());
			start();
		}

		@Override
		public void run() {
			try {
				
				
				ObjectInputStream userAppServerInputStream = new ObjectInputStream(appServerSocketInstance.getInputStream());
				System.out.println("second connected");

				if (request.getMessageFormat().equals("SPPROBE_MSG_IP_MSG")) {
					SS7Message_IP ipMsg = (SS7Message_IP) userAppServerInputStream.readObject();
					this.setName("Thread_get_IP_Msg");
					System.out.println(ipMsg);
					FileUtils.writeIP_MSG(ipMsg);
				} 
				else if (request.getMessageFormat().equals("SPPROBE_MSG_M3UA_MSG")) {
					SS7Message_M3UA m3uaMsg = (SS7Message_M3UA) userAppServerInputStream.readObject();
					System.out.println(m3uaMsg);
					this.setName("Thread_get_M3UA_Msg");
					FileUtils.writeM3UA_MSG(m3uaMsg);
				} 
				else if (request.getMessageFormat().equals("SPPROBE_MSG_M2PA_MSG")) {
					SS7Message_M2PA m2paMsg = (SS7Message_M2PA) userAppServerInputStream.readObject();
					System.out.println(m2paMsg);
					this.setName("Thread_get_M2PA_Msg");
					FileUtils.writeM2PA_MSG(m2paMsg);
				} 
				else {
					SPProbe_ERROR error = (SPProbe_ERROR) userAppServerInputStream.readObject();
					System.out.println(error);
				}
				userAppServerInputStream.close();
				appServerSocketInstance.close();
			} catch (IOException ie) {
				ie.printStackTrace();
			} catch (ClassNotFoundException ce) {
				ce.printStackTrace();
			}
		}

	}

}

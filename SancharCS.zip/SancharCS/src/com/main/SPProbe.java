package com.main;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;

import org.apache.log4j.Level;
import org.apache.log4j.PropertyConfigurator;

import com.logger.SPProbe_Logger;
import com.pojos.SPprobe_REQ;
import com.utils.CommonUtil;
public class SPProbe {

	public final int port_Num=1234;
	public void execute() throws Exception {
		ServerSocket serversocketInstance = new ServerSocket(port_Num);SPProbe_Logger.logger.info("Server is started at port  : "+port_Num);
		while(true){
			Socket socketInstance = serversocketInstance.accept();
			SPProbeThread thread = new SPProbeThread(socketInstance);
		}
	}

	public static void main(String[] args) {
		
		SPProbe_Logger.setLogger();
		SPProbe_Logger.logger.setLevel(Level.INFO);// set logger level
		SPProbe_Logger.logger.info("server is Started");
		
		
		SPProbe serverInstance = new SPProbe();
		try {
			serverInstance.execute();
		} catch (Exception e) {

			e.printStackTrace();
		}

	}

	private class SPProbeThread extends Thread{

		Socket socketInstance;
		public SPProbeThread(Socket socketInstance) {
			this.socketInstance=socketInstance;
			this.start();
		}
		
		@Override
		public void run() {
			
			try{ 
				ObjectInputStream inputStream = new ObjectInputStream(socketInstance.getInputStream());SPProbe_Logger.logger.info("Client is Connected");
				System.out.println("connected");
				SPprobe_REQ initialRequest = (SPprobe_REQ) inputStream.readObject();
				System.out.println(initialRequest);
				socketInstance.close();
				
				// Client starts here
				
				Socket spprobeClientSocketInstance = new Socket(initialRequest.getIpAddress(), initialRequest.getPort());
				System.out.println("second connected");
				ObjectOutputStream clientOutputStream = new ObjectOutputStream(spprobeClientSocketInstance.getOutputStream());
				
				if (initialRequest.getRequestType().equalsIgnoreCase("register")) {
					SPProbe_Logger.logger.info("Sending Register request");
					CommonUtil.registerRequest(initialRequest, clientOutputStream);
				 }
				else{
				     CommonUtil.registerRequest(initialRequest, clientOutputStream);
				     System.out.println("Unknown message");
				    }
				
				clientOutputStream.close();
				spprobeClientSocketInstance.close();
			}catch(IOException ie){
				ie.printStackTrace();
			}
			catch(ClassNotFoundException ce){
				ce.printStackTrace();
			}
		}
	}
}

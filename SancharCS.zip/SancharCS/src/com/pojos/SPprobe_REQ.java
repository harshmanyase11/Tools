package com.pojos;

import java.io.Serializable;

public class SPprobe_REQ implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private String requestType;
	
	private String messageType;
	
	private String messageFormat;
	
	private String ipAddress;
	
	private int port;
	
	private String sio;

	public String getRequestType() {
		return requestType;
	}

	public void setRequestType(String requestType) {
		this.requestType = requestType;
	}

	public String getMessageType() {
		return messageType;
	}

	public void setMessageType(String messageType) {
		this.messageType = messageType;
	}

	public String getMessageFormat() {
		return messageFormat;
	}

	public void setMessageFormat(String messageFormat) {
		this.messageFormat = messageFormat;
	}

	public String getIpAddress() {
		return ipAddress;
	}

	public void setIpAddress(String ipAddress) {
		this.ipAddress = ipAddress;
	}

	public int getPort() {
		return port;
	}

	public void setPort(int port) {
		this.port = port;
	}

	public String getSio() {
		return sio;
	}

	public void setSio(String sio) {
		this.sio = sio;
	}

	@Override
	public String toString() {
		return "SPprobe_REQ [requestType=" + requestType + ", messageType="
				+ messageType + ", messageFormat=" + messageFormat
				+ ", ipAddress=" + ipAddress + ", port=" + port + ", sio="
				+ sio + "]";
	}
	
	
}

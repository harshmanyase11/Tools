package com.pojos;

import java.io.Serializable;

public class SS7Message_IP implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private String ipRaw;
	
	private int ipRawLength;

	public String getIpRaw() {
		return ipRaw;
	}

	public void setIpRaw(String ipRaw) {
		this.ipRaw = ipRaw;
	}

	public int getIpRawLength() {
		return ipRawLength;
	}

	public void setIpRawLength(int ipRawLength) {
		this.ipRawLength = ipRawLength;
	}

	@Override
	public String toString() {
		return "SS7Message_IP [ipRaw=" + ipRaw + ", ipRawLength=" + ipRawLength
				+ "]";
	}
	
	
}

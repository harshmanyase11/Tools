package com.pojos;

import java.io.Serializable;

public class SPProbe_ERROR implements Serializable {

	
	private String errorCode;
	
	private String errorType;

	public String getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	public String getErrorType() {
		return errorType;
	}

	public void setErrorType(String errorType) {
		this.errorType = errorType;
	}

	@Override
	public String toString() {
		return "SPProbe_ERROR [errorCode=" + errorCode + ", errorType="
				+ errorType + "]";
	}
	
	
}

package com.pojos;

import java.io.Serializable;

public class SS7Message_M2PA implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private String messageType;
	
	private int bsn;
	
	private String bib;
	
	private int fsn;
	
	private String fib;
	
	private short li;
	
	private String sio;

	public String getMessageType() {
		return messageType;
	}

	public void setMessageType(String messageType) {
		this.messageType = messageType;
	}

	public int getBsn() {
		return bsn;
	}

	public void setBsn(int bsn) {
		this.bsn = bsn;
	}

	public String getBib() {
		return bib;
	}

	public void setBib(String bib) {
		this.bib = bib;
	}

	public int getFsn() {
		return fsn;
	}

	public void setFsn(int fsn) {
		this.fsn = fsn;
	}

	public String getFib() {
		return fib;
	}

	public void setFib(String fib) {
		this.fib = fib;
	}

	public short getLi() {
		return li;
	}

	public void setLi(short li) {
		this.li = li;
	}

	public String getSio() {
		return sio;
	}

	public void setSio(String sio) {
		this.sio = sio;
	}

	@Override
	public String toString() {
		return "SS7Message_M2PA [messageType=" + messageType + ", bsn=" + bsn
				+ ", bib=" + bib + ", fsn=" + fsn + ", fib=" + fib + ", li="
				+ li + ", sio=" + sio + "]";
	}
	
	
}

package com.pojos;

import java.io.Serializable;

public class SS7Message_M3UA implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private String m3uaRaw;
	
	private int m3uaRawLength;
	
	private int opc;
	
	private int dpc;
	
	private String messageType; 
	
	private String si;
	
	private String ni;
	
	private String mp;
	
	private String sls;

	public String getM3uaRaw() {
		return m3uaRaw;
	}

	public void setM3uaRaw(String m3uaRaw) {
		this.m3uaRaw = m3uaRaw;
	}

	public int getM3uaRawLength() {
		return m3uaRawLength;
	}

	public void setM3uaRawLength(int m3uaRawLength) {
		this.m3uaRawLength = m3uaRawLength;
	}

	public int getOpc() {
		return opc;
	}

	public void setOpc(int opc) {
		this.opc = opc;
	}

	public int getDpc() {
		return dpc;
	}

	public void setDpc(int dpc) {
		this.dpc = dpc;
	}

	public String getMessageType() {
		return messageType;
	}

	public void setMessageType(String messageType) {
		this.messageType = messageType;
	}

	public String getSi() {
		return si;
	}

	public void setSi(String si) {
		this.si = si;
	}

	public String getNi() {
		return ni;
	}

	public void setNi(String ni) {
		this.ni = ni;
	}

	public String getMp() {
		return mp;
	}

	public void setMp(String mp) {
		this.mp = mp;
	}

	public String getSls() {
		return sls;
	}

	public void setSls(String sls) {
		this.sls = sls;
	}

	@Override
	public String toString() {
		return "SS7Message_M3UA [m3uaRaw=" + m3uaRaw + ", m3uaRawLength="
				+ m3uaRawLength + ", opc=" + opc + ", dpc=" + dpc
				+ ", messageType=" + messageType + ", si=" + si + ", ni=" + ni
				+ ", mp=" + mp + ", sls=" + sls + "]";
	}
	
	
}

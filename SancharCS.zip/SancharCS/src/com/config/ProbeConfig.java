package com.config;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

import javax.swing.text.StyledEditorKit.BoldAction;

import org.apache.log4j.PropertyConfigurator;

import com.logger.SPProbe_Logger;

public class ProbeConfig extends Properties {

	/**
	 * @author harsh.manyase
	 *
	 */

	/**
	 * 
	 */
	private static final long serialVersionUID = -9053626214304860426L;

	private String configFileName;//TODO Put File name with file path
	private Properties prop;
	private FileInputStream inStream;
	private FileOutputStream outStream;
	private File fileInstance;
	private Map<String, String> defaultValues;

	public String getConfigFileName() {
		return configFileName;
	}

	public void setConfigFileName(String configFileName) {
		this.configFileName = configFileName;
	}

	public ProbeConfig() {
		loadConfigFile();

	}

	public FileOutputStream getOutStream() {
		return outStream;
	}

	public FileInputStream getInStream() {
		return inStream;
	}

	public File getFileInstance() {
		return fileInstance;
	}

	public ProbeConfig(String FileName) {
		this.configFileName = FileName;		
		loadConfigFile();
	}
	public ProbeConfig(String FileName,Map<String, String> Default)
	{		
		this.configFileName = FileName;
		this.defaultValues=Default;
		loadConfigFile();
	}

	private void loadConfigFile() {
		if (checkFile()) {
			
			this.prop = new Properties();
			try {
				this.inStream = new FileInputStream(this.configFileName);
				// outStream=new FileOutputStream(configFileName);
				this.prop.load(inStream);
				SPProbe_Logger.logger
						.info("Configuration  file  :"+this.configFileName+"  is loaded successfully");
			} catch (IOException e) {
				// e.printStackTrace();
				SPProbe_Logger.logger
						.error("Error in reading configuration file  :"+this.configFileName);
			}
		}
	}

	public boolean checkFile() {

		this.fileInstance = new File(this.configFileName);
		if (this.fileInstance.exists()) {
			if(this.fileInstance.length() == 0)
			{
				SPProbe_Logger.logger.info("Configuration file  :"+this.configFileName+"   is empty");
			}else{
				SPProbe_Logger.logger.info("Configuration file  :"+this.configFileName+"   is loading");
			}			
			return true;
		} else {
			SPProbe_Logger.logger.warn("Configuration file :"+this.configFileName+" not exist");
			return false;
		}

	}

	public boolean checkAllValues() {
		boolean result=false;
		if (this.prop != null) {
			
			Set<Object> keys = this.getAllKeys();
			SPProbe_Logger.logger.debug("Configuration file : "+this.configFileName+" values");
			for (Object k : keys) {
				String key = (String) k;
				if(this.prop.getProperty(key).equals(null))
				{
					SPProbe_Logger.logger.warn("Value is missing at key="+key);
				    result=false;				
				}
				else
				{
					SPProbe_Logger.logger.debug(key + " = "+ this.getPropertyValue(key));
				    result=true;				
				}			
			}
		}
		return result;

	}

	public void showAllProperty() throws IOException {
		if (this.prop != null) {
			Set<Object> keys = this.getAllKeys();
			SPProbe_Logger.logger.debug("Configuration file values");
			for (Object k : keys) {
				String key = (String) k;
				// System.out.println(key+" = "+this.getPropertyValue(key));
				SPProbe_Logger.logger.debug(key + " = "
						+ this.getPropertyValue(key));
			}

		}
	}

	public Set<Object> getAllKeys() {
		if (this.prop != null) {
			Set<Object> keys = this.prop.keySet();
			return keys;
		}
		return null;
	}

	public String getPropertyValue(String key) {
		if (this.prop != null) {
			if (this.prop.getProperty(key).equals("")) {
				SPProbe_Logger.logger.warn("Value is missing at key=" + key);
				SPProbe_Logger.logger.info("system is loading default value");
				if(this.defaultValues!=null)
				return this.defaultValues.get(key);
				else
					SPProbe_Logger.logger.warn("No default value find Please Provide ...");
			} else {				
				return this.prop.getProperty(key);
			}
		}
		return null;
	}

	public String getPropertyValue(String key, String defaultValue) {
		if(this.prop!=null)		
		return prop.getProperty(key, defaultValue);
		return defaultValue;
	}
	public void setDefaultValues(Map<String, String> Defaultmap)
	{
		this.defaultValues=Defaultmap;
		
	}

	public boolean checkKey(String key) {
		if (this.prop.containsKey(key)) {

			return true;
		} else {
			return false;
		}
	}

	public Boolean setPropertyValue(String key, String value) {
		if (this.prop.containsKey(key)) {
			this.prop.setProperty(key, value);
			return true;
		} else {
			SPProbe_Logger.logger
					.warn("Requested key is not present in file :"+this.configFileName+"  Please check ....");
			return false;
		}

	}

	public void setPropertyVal(String key, String value) {
		this.prop.setProperty(key, value);
	}

	
	public static void main(String[] args) {

		PropertyConfigurator.configure("Log4j.properties");// set logger
															// Properties
		
		HashMap<String, String> defaultval=new HashMap<String, String>();
		defaultval.put("dbIpAddress", "192.168.2.3");
		defaultval.put("dbUserName", "system");
		defaultval.put("dbPassWord", "manager");
		defaultval.put("dbUrl", "jdbc:oracle:thin:@localhost:1521:xe");
		defaultval.put("dbDriver", "oracle.jdbc.OracleDriver");
		
		
		ProbeConfig config = new ProbeConfig("firstconfig",defaultval);

		//config.showAllProperty();
		config.checkAllValues();
         ProbeConfig con=new ProbeConfig("secondConfig");
         con.checkAllValues();
         ProbeConfig con3=new ProbeConfig("thirdconfig");
         con3.checkAllValues();
		
		
		//System.out.println(config.getPropertyValue("dbIpAddress"));
         
	}

}

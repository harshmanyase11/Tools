package com.utils;

import java.io.FileNotFoundException;
import java.io.UnsupportedEncodingException;

import com.Dao.Probe_DB_Connection;
import com.Dao.SPprobe_DAO;
import com.Dao.SPprobe_File_Handler;
import com.pojos.SS7Message_IP;
import com.pojos.SS7Message_M2PA;
import com.pojos.SS7Message_M3UA;

public class FileUtils {
	
   
	
	public static void writeIP_MSG(SS7Message_IP ipMsg)throws FileNotFoundException,UnsupportedEncodingException{
		
	   // SPprobe_DAO.getDaoInstance().saveIP_MSG(ipMsg);
	   // Probe_DB_Connection instance=Probe_DB_Connection.getProbe_DB_Instance();
	    Probe_DB_Connection.getProbe_DB_Instance().saveIP_MSG(ipMsg);
	     SPprobe_File_Handler.getInstance().writeIP_MSG(ipMsg);
		
	}
	
	public static void writeM3UA_MSG(SS7Message_M3UA m3uaMsg)throws FileNotFoundException,UnsupportedEncodingException{
		//SPprobe_DAO.getDaoInstance().saveM3UA_MSG(m3uaMsg);
		Probe_DB_Connection.getProbe_DB_Instance().saveM3UA_MSG(m3uaMsg);
		SPprobe_File_Handler.getInstance().writeM3UA_MSG(m3uaMsg);
	}

	public static void writeM2PA_MSG(SS7Message_M2PA m2paMsg)throws FileNotFoundException,UnsupportedEncodingException{
	   //  SPprobe_DAO.getDaoInstance().saveM2PA_MSG(m2paMsg);
		Probe_DB_Connection.getProbe_DB_Instance().saveM2PA_MSG(m2paMsg);
		SPprobe_File_Handler.getInstance().writeM2PA_MSG(m2paMsg);
	}
	
	
}

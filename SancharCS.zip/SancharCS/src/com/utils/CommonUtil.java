package com.utils;

import java.io.IOException;
import java.io.ObjectOutputStream;

import com.logger.SPProbe_Logger;
import com.pojos.SPProbe_ERROR;
import com.pojos.SPprobe_REQ;
import com.pojos.SS7Message_IP;
import com.pojos.SS7Message_M2PA;
import com.pojos.SS7Message_M3UA;

public class CommonUtil {

	public static void registerRequest(SPprobe_REQ initialRequest,ObjectOutputStream clientOutputStream) throws IOException{

		if (initialRequest.getMessageType().equals("ISUP")) {
			SPProbe_Logger.logger.info("checking message type");
			if (initialRequest.getMessageFormat().equals("SPPROBE_MSG_IP_MSG")) {
				
				SS7Message_IP ipMsg = new SS7Message_IP();
				String msg = "IP ISUP";
				ipMsg.setIpRaw(msg);
				ipMsg.setIpRawLength(msg.length());
				
				clientOutputStream.writeObject(ipMsg);
			} 
			else if (initialRequest.getMessageFormat().equals("SPPROBE_MSG_M3UA_MSG")) {
				
				SS7Message_M3UA m3uaMsg = new SS7Message_M3UA();
				String msg = "M3UA ISUP";
				m3uaMsg.setM3uaRaw(msg);
				m3uaMsg.setM3uaRawLength(msg.length());
				m3uaMsg.setMessageType("M3UA_Message_type");
				m3uaMsg.setMp("M3UA_MP");
				m3uaMsg.setNi("M3UA_NI");
				m3uaMsg.setSi("M3UA_SI");
				m3uaMsg.setSls("M3UA_SLS");
				m3uaMsg.setDpc(10);
				m3uaMsg.setOpc(10);
				
				clientOutputStream.writeObject(m3uaMsg);
			}
			else if (initialRequest.getMessageFormat().equals("SPPROBE_MSG_M2PA_MSG")) {

				SS7Message_M2PA m2paMsg = new SS7Message_M2PA();
				String msg = "M2PA ISUP";
				m2paMsg.setMessageType("M2PA_Message_type");
				m2paMsg.setBib("M2PA_BIB");
				m2paMsg.setFib("M2PA_FIB");
				m2paMsg.setSio("M2PA_SIO");
				m2paMsg.setBsn(10);
				m2paMsg.setFsn(10);
				m2paMsg.setLi((short)10);
				
				clientOutputStream.writeObject(m2paMsg);
			}
			else {
				
				SPProbe_ERROR error = new SPProbe_ERROR();
				error.setErrorCode("0x948");
				error.setErrorType("INVALID_MSG_FMT");
				SPProbe_Logger.logger.error("Error code : 0x948 : INVALID_MSG_FMT");						
				clientOutputStream.writeObject(error);
			}
		}
		else if (initialRequest.getMessageType().equals("SCCP")) {
			
			if (initialRequest.getMessageFormat().equals("SPPROBE_MSG_IP_MSG")) {
				
				SS7Message_IP ipMsg = new SS7Message_IP();
				String msg = "IP SCCP";
				ipMsg.setIpRaw(msg);
				ipMsg.setIpRawLength(msg.length());
				
				clientOutputStream.writeObject(ipMsg);
			} 
			else if (initialRequest.getMessageFormat().equals("SPPROBE_MSG_M3UA_MSG")) {
				
				SS7Message_M3UA m3uaMsg = new SS7Message_M3UA();
				String msg = "M3UA ISUP";
				m3uaMsg.setM3uaRaw(msg);
				m3uaMsg.setM3uaRawLength(msg.length());
				m3uaMsg.setMessageType("M3UA_Message_type");
				m3uaMsg.setMp("M3UA_MP");
				m3uaMsg.setNi("M3UA_NI");
				m3uaMsg.setSi("M3UA_SI");
				m3uaMsg.setSls("M3UA_SLS");
				m3uaMsg.setDpc(10);
				m3uaMsg.setOpc(10);
				
				clientOutputStream.writeObject(m3uaMsg);

			}
			else if (initialRequest.getMessageFormat().equals("SPPROBE_MSG_M2PA_MSG")) {

				SS7Message_M2PA m2paMsg = new SS7Message_M2PA();
				String msg = "M2PA ISUP";
				m2paMsg.setMessageType("M2PA_Message_type");
				m2paMsg.setBib("M2PA_BIB");
				m2paMsg.setFib("M2PA_FIB");
				m2paMsg.setSio("M2PA_SIO");
				m2paMsg.setBsn(10);
				m2paMsg.setFsn(10);
				m2paMsg.setLi((short)10);
				
				clientOutputStream.writeObject(m2paMsg);
			}
			else {
				SPProbe_ERROR error = new SPProbe_ERROR();
				error.setErrorCode("0x948");
				error.setErrorType("INVALID_MSG_FMT");
				SPProbe_Logger.logger.error("Error code : 0x948 : UNKNOWN_MSG_FMT");				
				clientOutputStream.writeObject(error);
			}
		}
		else{
			SPProbe_ERROR error = new SPProbe_ERROR();
			error.setErrorCode("0x948");
			error.setErrorType("INVALID_MSG_TYPE");
			SPProbe_Logger.logger.error("Error code :0x948 : INVALID_MSG_TYPE");
			clientOutputStream.writeObject(error);
		}
	}
}

package com.logger;
import org.apache.log4j.Appender;
import org.apache.log4j.Layout;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.apache.log4j.spi.ErrorHandler;
import org.apache.log4j.spi.Filter;
import org.apache.log4j.spi.LoggingEvent;
public class SPProbe_Logger {
	
	
  public static Logger logger=Logger.getLogger(SPProbe_Logger.class.getName());// Maintain log file using Log4j.jar	
	
    
	public static Logger getLogger()
	{
		return logger;
	}
	
	
	
	public static void setLogger()
	{
		PropertyConfigurator.configure("Log4j.properties");// set logger Properties
		logger.info("SPprobe Logger is started");	
		
	}
	
	

}


class ProbeLogger extends Logger
{
	private String LogFileName;
    private Logger log=Logger.getLogger(ProbeLogger.class.getName());
    
    
    
    
	public String getLogFileName() {
		return LogFileName;
	}

	public void setLogFileName(String logFileName) {
		LogFileName = logFileName;
	}

	protected ProbeLogger(String name) {
		super(name);
		
	}
  
	protected Logger getGlobalLogger()
	{
		return super.getRootLogger();
	}
	
	protected void setProbeLogger()
	{
	   LogManager logmgr=new LogManager();
	   
		
	}
	
	protected Logger getProbeLogger(String logName)
	{
		return Logger.getLogger(logName);		
	}
	
	protected void stopLogger()
	{
		 log.shutdown();
		
	}
	
	protected void Loggerconfig()
	{
		log=Logger.getRootLogger();
		log.addAppender(new Appender() {
			
			@Override
			public void setName(String arg0) {
				
				
			}
			
			@Override
			public void setLayout(Layout arg0) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void setErrorHandler(ErrorHandler arg0) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public boolean requiresLayout() {
				// TODO Auto-generated method stub
				return false;
			}
			
			@Override
			public String getName() {
				// TODO Auto-generated method stub
				return null;
			}
			
			@Override
			public Layout getLayout() {
				// TODO Auto-generated method stub
				return null;
			}
			
			@Override
			public Filter getFilter() {
				// TODO Auto-generated method stub
				return null;
			}
			
			@Override
			public ErrorHandler getErrorHandler() {
				// TODO Auto-generated method stub
				return null;
			}
			
			@Override
			public void doAppend(LoggingEvent arg0) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void close() {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void clearFilters() {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void addFilter(Filter arg0) {
				// TODO Auto-generated method stub
				
			}
		});
		
		
	}
	
	


}

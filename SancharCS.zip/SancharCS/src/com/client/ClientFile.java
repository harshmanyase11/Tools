package com.client;


import java.io.BufferedReader;
import java.io.File;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.io.PrintWriter;
import java.net.Socket;

public class ClientFile {
	
	
	public void execute()throws Exception
	{
		
		Socket socketInstance=new Socket("localhost",5555);
		PrintStream ps=new PrintStream(socketInstance.getOutputStream());
		ps.println("client connected");
		
		BufferedReader br=new BufferedReader(new InputStreamReader(socketInstance.getInputStream()));
		
		PrintWriter pw=new PrintWriter(new File("output.csv"));
		String message=null;
		while((message=br.readLine())!=null){
			//System.out.println(message);
			if(message.equalsIgnoreCase("done"))
				break;
			else{
				System.out.println(message);
				//pw.println(message);
			}
		}
		
		BufferedReader br1=new BufferedReader(new InputStreamReader(System.in));
		String input=br1.readLine();
		ps.println(input);
		
		/*
		if(input.equalsIgnoreCase("1"))
		{
			while((message=br.readLine())!=null){
				if(message.equalsIgnoreCase("done"))
					break;
				else{
					pw.println(message);
				}
			}
		}
		else if(input.equalsIgnoreCase("2"))
		{
			System.out.println("In second case");
			System.out.println(br.readLine());
			input=br1.readLine();
			ps.println(input);
			while((message=br.readLine())!=null)
			{
				if(message.equalsIgnoreCase("done"))
					break;
				else{
					pw.println(message);
				}
			}
		}*/
		
		
		br.close();
		pw.close();
		ps.println("done");
		ps.close();
		socketInstance.close();
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
			ClientFile clientInstance=new ClientFile();
			try {
				clientInstance.execute();
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	}


}

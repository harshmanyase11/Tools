package com.client;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketTimeoutException;

public class SPprobeSendStream {
	
	
	
	
	public void execute() throws Exception {
		ServerSocket serversocketInstance = new ServerSocket(5555);
		Socket socketInstance = serversocketInstance.accept();
		//socketInstance.setSoTimeout(10000);
		BufferedReader inputstreamInstance = new BufferedReader(new InputStreamReader(socketInstance.getInputStream()));
		PrintStream printstreamInstance = new PrintStream(socketInstance.getOutputStream());
        DataInputStream dr=new DataInputStream(socketInstance.getInputStream());
		try {
			String line = null;
			
			String message = null;
			try {
				message = inputstreamInstance.readLine();
			} catch (SocketTimeoutException se) {
			}
			boolean flag = false;
			if (message == null)
				flag = true;

			if (!flag) {
				BufferedReader br1_ip = new BufferedReader(new InputStreamReader(new FileInputStream("IP_MSG_FILE.txt")));
				BufferedReader br2_m2pa = new BufferedReader(new InputStreamReader(new FileInputStream("M2PA_MSG_FILE.txt")));
				BufferedReader br3_m3ua = new BufferedReader(new InputStreamReader(new FileInputStream("M3UA_MSG_FILE.txt")));
				System.out.println(message);

				if (message != null) {

					System.out.println("File Read");

					// Interact with client
					/*printstreamInstance.println("1.All file ");
					printstreamInstance.println("2.Specific columns");
					printstreamInstance.println("Enter your demand ");
					printstreamInstance.println("done");*/

					// waiting for client to respond
					
					printstreamInstance.println("Select Type of File you want ");
					printstreamInstance.println("1.IP_Msg_File ");
					printstreamInstance.println("2.M2PA_Msg_File ");
					printstreamInstance.println("3.M3UA_Msg_File");
					printstreamInstance.println("Enter your Choice ");
					int responseFromClient = Integer.parseInt(inputstreamInstance.readLine());
					//responseFromClient=Integer.parseInt(dr.readUTF());
					System.out.println("client responce  : "+responseFromClient);
					switch(responseFromClient)
					{
					case 1:
						printstreamInstance.println("1.All file ");
						printstreamInstance.println("2.Specific columns");
						printstreamInstance.println("Enter your choice ");
						int responseFromClient2 = Integer.parseInt(inputstreamInstance.readLine());
						switch (responseFromClient2)
						{
						case 1:
							while ((line = br1_ip.readLine()) != null)
								printstreamInstance.println(line);
							break;
						case 2:
							// Again interact with client to know which columns to
							// send
							System.out.println("In second case");
							printstreamInstance
									.println("Enter specific number of columns seprating with ,  (e.g=  1,2 )   =");
							String columns[] = inputstreamInstance.readLine()
									.split(",");
							while ((line = br1_ip.readLine()) != null) 
							{
								// Split the data from file to get specific columns
								String colData[] = line.split(",");
								StringBuilder sb = new StringBuilder();
								for (int i = 0; i < colData.length; i++) {
									for (int j = 0; j < columns.length; j++) {
										if (i == Integer.parseInt(columns[j]) - 1) {
											sb.append(colData[i]);
											if (i != colData.length - 1)
												sb.append(",");
										}
									}
								}
								printstreamInstance.println(sb.toString());
							}
							break;
						default:
							break;
						}
						   break;
					case 2:  
						printstreamInstance.println("1.All file ");
						printstreamInstance.println("2.Specific columns");
						printstreamInstance.println("Enter your choice ");
						int responseFromClient3 = Integer.parseInt(inputstreamInstance.readLine());
						switch (responseFromClient3)
						{
						case 1:
							while ((line = br2_m2pa.readLine()) != null)
								printstreamInstance.println(line);
							break;
						case 2:
							// Again interact with client to know which columns to
							// send
							System.out.println("In second case");
							printstreamInstance
									.println("Enter specific number of columns seprating with ,  (e.g=  1,2 )   =");
							String columns[] = inputstreamInstance.readLine()
									.split(",");
							while ((line = br2_m2pa.readLine()) != null) 
							{
								// Split the data from file to get specific columns
								String colData[] = line.split(",");
								StringBuilder sb = new StringBuilder();
								for (int i = 0; i < colData.length; i++) {
									for (int j = 0; j < columns.length; j++) {
										if (i == Integer.parseInt(columns[j]) - 1) {
											sb.append(colData[i]);
											if (i != colData.length - 1)
												sb.append(",");
										}
									}
								}
								printstreamInstance.println(sb.toString());
							}
							break;
						default:
							break;
						}
						   break;
					case 3: 
						printstreamInstance.println("1.All file ");
						printstreamInstance.println("2.Specific columns");
						printstreamInstance.println("Enter your choice ");
						int responseFromClient4 = Integer.parseInt(inputstreamInstance.readLine());
						switch (responseFromClient4)
						{
						case 1:
							while ((line = br3_m3ua.readLine()) != null)
								printstreamInstance.println(line);
							break;
						case 2:
							// Again interact with client to know which columns to
							// send
							
							printstreamInstance.println("Enter specific number of columns seprating with ,  (e.g=  1,2 )   =");
							String columns[] = inputstreamInstance.readLine().split(",");
							while ((line = br3_m3ua.readLine()) != null) 
							{
								// Split the data from file to get specific columns
								String colData[] = line.split(",");
								StringBuilder sb = new StringBuilder();
								for (int i = 0; i < colData.length; i++) {
									for (int j = 0; j < columns.length; j++) {
										if (i == Integer.parseInt(columns[j]) - 1) {
											sb.append(colData[i]);
											if (i != colData.length - 1)
												sb.append(",");
										}
									}
								}
								printstreamInstance.println(sb.toString());
							}
							break;
						default:
							break;
						}
						   break;
					
					}
					printstreamInstance.println("done");
					String trigger = inputstreamInstance.readLine();
					if (trigger.equalsIgnoreCase("done"))
						serversocketInstance.close();
				}
			} 
			
			else {
				
				
			     }
		
		
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (inputstreamInstance != null) {
				try {
					printstreamInstance.close();
					inputstreamInstance.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}

		}

	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SPprobeSendStream serverInstance = new SPprobeSendStream();
		try {
			serverInstance.execute();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
	
}

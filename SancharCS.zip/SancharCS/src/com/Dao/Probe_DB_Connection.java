package com.Dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;

import com.logger.SPProbe_Logger;
import com.pojos.SS7Message_IP;
import com.pojos.SS7Message_M2PA;
import com.pojos.SS7Message_M3UA;

public class Probe_DB_Connection  {
	
	private static Connection connectionInstance;
	private PreparedStatement preparedStatementInstance=null;
	private Statement statementInstance=null ;
	private static Probe_DB_Connection probe_DB_Instances=null;
	
	private Probe_DB_Connection() {
		// TODO Auto-generated constructor stub
		super();
	}
	
	
	public static Connection getConnectionInstance() {
		return connectionInstance= SPprobe_DAO.getConnectionInstance();
	}


	public static void setConfigFile(String filePath)
	{
		SPprobe_DAO.setConfiguration_FIle_Name(filePath);
	}
	public void closeConnection()
	{
		SPprobe_DAO.closeDbConnection();
	}
	
	

	public static Probe_DB_Connection getProbe_DB_Instance() {
		if (probe_DB_Instances != null) {
			return probe_DB_Instances;
		} else {
			return probe_DB_Instances =new Probe_DB_Connection();
		}
	}

	

	

	// to insert IP msg
	public void saveIP_MSG(SS7Message_IP msgdata) {
		try {
			// getConnection();
			// String
			// query="insert into SS7Message_IP_Table(ipraw ,iprawlen ) values('asjdjasjd',45454)";
			String query = "insert into SS7Message_IP_Table(ipraw ,iprawlen ) values('"
					+ msgdata.getIpRaw()
					+ "', '"
					+ msgdata.getIpRawLength()
					+ "')";
			statementInstance = connectionInstance.createStatement();
			int result = statementInstance.executeUpdate(query);
			if (result != 0)
				System.out
						.println("SS7Message_IP message inserted into DATABASE");
			else
				System.out
						.println("Error : SS7Message_IP message not inserted into DATABASE");
		} catch (SQLException ex) {
			// ex.printStackTrace();
			SPProbe_Logger.logger.error("Error in Storing IP message   :"
					+ ex.getMessage());
		} finally {
			try {
				if (preparedStatementInstance != null)
					preparedStatementInstance.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

	}

	// to insert M2PA Message
	public void saveM2PA_MSG(SS7Message_M2PA msgdata) {
		try {

			preparedStatementInstance = connectionInstance
					.prepareStatement("insert into SS7Message_M2PA_Table(message_type ,bsn,bib,fsn,fib,li,sio ) values('"
							+ msgdata.getMessageType()
							+ "','"
							+ msgdata.getBsn()
							+ "','"
							+ msgdata.getBib()
							+ "','"
							+ msgdata.getFsn()
							+ "','"
							+ msgdata.getFib()
							+ "','"
							+ msgdata.getLi()
							+ "','" + msgdata.getSio() + "')  ");
			int result = preparedStatementInstance.executeUpdate();
			if (result != 0)
				System.out
						.println("SS7Message_M2PA message inserted into DATABASE");
			else
				System.out
						.println("Error : SS7Message_M2PA message not inserted into DATABASE");
		} catch (SQLException ex) {
			System.out.println("M2PA message is not inserted.");
			System.out.println("Check connection.");
			SPProbe_Logger.logger.error("Error in Storing M2PA message   :"
					+ ex.getMessage());
			ex.printStackTrace();

		} finally {
			try {
				if (preparedStatementInstance != null)
					preparedStatementInstance.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

	}

	// to insert M3UA msg
	public void saveM3UA_MSG(SS7Message_M3UA msgdata) {
		try {

			preparedStatementInstance = connectionInstance.prepareStatement("insert into SS7Message_M3UA_Table(m3uaRaw ,m3uaRawLen,opc,dpc,Message_Type,si,ni,mp,sls ) values('"
							+ msgdata.getM3uaRaw()
							+ "','"
							+ msgdata.getM3uaRawLength()
							+ "','"
							+ msgdata.getOpc()
							+ "','"
							+ msgdata.getDpc()
							+ "','"
							+ msgdata.getMessageType()
							+ "','"
							+ msgdata.getSi()
							+ "','"
							+ msgdata.getNi()
							+ "','"
							+ msgdata.getMp()
							+ "','"
							+ msgdata.getSls()
							+ "')  ");
			int result = preparedStatementInstance.executeUpdate();
			if (result != 0)
				System.out
						.println("SS7Message_M3UA message inserted into DATABASE");
			else
				System.out
						.println("Error : SS7Message_M3UA message not inserted into DATABASE");
		} catch (SQLException ex) {
			ex.printStackTrace();
			SPProbe_Logger.logger.error("Error in Storing M3UA message   :"
					+ ex.getMessage());
		} finally {
			try {
				if (preparedStatementInstance != null)
					preparedStatementInstance.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

	}

}

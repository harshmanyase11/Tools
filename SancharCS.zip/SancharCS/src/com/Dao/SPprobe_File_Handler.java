package com.Dao;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.PrintWriter;

import javax.swing.text.StyledEditorKit.BoldAction;

import oracle.jdbc.driver.DBConversion;

import com.logger.SPProbe_Logger;
import com.pojos.SS7Message_IP;
import com.pojos.SS7Message_M2PA;
import com.pojos.SS7Message_M3UA;

public class SPprobe_File_Handler {
	
	private String IP_Msg_File="IP_MSG_FILE.txt";
	private String M2PA_Msg_File="M2PA_MSG_FILE.txt";
	private String M3UA_Msg_File="M3UA_MSG_FILE.txt";
	static SPprobe_File_Handler fileInstance;
   
	
	
	public String getIP_Msg_File() {
		return IP_Msg_File;
	}


	public void setIP_Msg_File(String iP_Msg_File) {
		IP_Msg_File = iP_Msg_File;
	}


	public String getM2PA_Msg_File() {
		return M2PA_Msg_File;
	}


	public void setM2PA_Msg_File(String m2pa_Msg_File) {
		M2PA_Msg_File = m2pa_Msg_File;
	}


	public String getM3UA_Msg_File() {
		return M3UA_Msg_File;
	}


	public void setM3UA_Msg_File(String m3ua_Msg_File) {
		M3UA_Msg_File = m3ua_Msg_File;
	}
	
	
	
	private boolean validateFile()
	{
		File Ip_file  =new  File(IP_Msg_File);
		File m2pa_file=new  File(M2PA_Msg_File);
		File m3ua_file=new  File(M3UA_Msg_File);
		boolean isfile=false;
		if(Ip_file.exists())
			{System.out.println("Ip_Msg txt file exists");isfile=true;}
		else
			{System.out.println("Ip_Msg file does Not Exists Please provide"); isfile=false;}
		
		if(m2pa_file.exists())
			{System.out.println("M2PA txt file exists");isfile=true;}
		else
			{System.out.println("M2PA file does Not Exists Please provide ");isfile=false;}
		
		if(m3ua_file.exists())
			{System.out.println("M3UA file exists");isfile=true;}
		else
			{System.out.println("M3UA file does Not Exists Please provide");isfile=false;}		
		
		
		return isfile;
		
	}
	
	public SPprobe_File_Handler() {
		// TODO Auto-generated constructor stub
		this.IP_Msg_File="IP_MSG_FILE.txt";
		this.M2PA_Msg_File="M2PA_MSG_FILE.txt";
		this.M3UA_Msg_File="M3UA_MSG_FILE.txt";
		validateFile();
		
	}
	public static  SPprobe_File_Handler getInstance()
	{
		if(fileInstance!=null)
		{System.out.println("Return instance");
			return fileInstance;
			
		}
		else
		{   System.out.println("Return new object");
			return fileInstance=new SPprobe_File_Handler();
		}
	}
	
	public  void writeIP_MSG(SS7Message_IP IP_msg)
	{
		PrintWriter pw;
		try {
			pw = new PrintWriter(new FileOutputStream(IP_Msg_File,true));
			pw.println(IP_msg);
			pw.close();
			SPProbe_Logger.logger.info("Write data into file");
		} catch (FileNotFoundException e) {
			SPProbe_Logger.logger.error("IP_MSG File NOT FOUND ");
			e.printStackTrace();
		}
		
		
	}
	
	public void writeM2PA_MSG(SS7Message_M2PA M2PA_msg) 
	{
		PrintWriter pw;
		try {
			pw = new PrintWriter(new FileOutputStream(M2PA_Msg_File,true));
			pw.println(M2PA_msg);
			pw.close();
			SPProbe_Logger.logger.info("Write data into file");
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			SPProbe_Logger.logger.error("M2PA_MSG File NOT FOUND ");
			e.printStackTrace();
		}
		
		
	}
	
	
	public void writeM3UA_MSG(SS7Message_M3UA  M3UA_msg) 
	{
		PrintWriter pw;
		try {
			pw = new PrintWriter(new FileOutputStream(M3UA_Msg_File,true));
			pw.println(M3UA_msg);
			pw.close();
			SPProbe_Logger.logger.info("Write data into file");
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			SPProbe_Logger.logger.error("M3UA_MSG File NOT FOUND ");
			e.printStackTrace();
		}
		
	}
	
	

}

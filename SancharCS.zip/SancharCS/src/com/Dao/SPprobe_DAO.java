package com.Dao;

import java.io.Serializable;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;

import com.config.ProbeConfig;
import com.logger.SPProbe_Logger;

public class SPprobe_DAO implements Serializable {

	protected static Connection connectionInstance;
	
	protected static String dbUserName;// ="system";
	protected static String dbPassWord;// ="manager";
	protected static String dbUrl;// ="jdbc:oracle:thin:@localhost:1521:xe";
	protected static String dbDriver;// ="oracle.jdbc.OracleDriver";
	protected static SPprobe_DAO daoInstance = null;
	protected static String Configuration_File_Name;

	public static String getDbUserName() {
		return dbUserName;
	}

	public static void setDbUserName(String dbUserName) {
		SPprobe_DAO.dbUserName = dbUserName;
	}

	public static String getDbPassWord() {
		return dbPassWord;
	}

	public static void setDbPassWord(String dbPassWord) {
		SPprobe_DAO.dbPassWord = dbPassWord;
	}

	public static String getDbUrl() {
		return dbUrl;
	}

	public static void setDbUrl(String dbUrl) {
		SPprobe_DAO.dbUrl = dbUrl;
	}

	public static Connection getConnectionInstance() {
		
		if(connectionInstance==null)
		{			
			connectionInstance=SPprobe_DAO.getConnection();
		}
		return connectionInstance;
	}

	
	

	public static String getDbDriver() {
		return dbDriver;
	}

	public static void setDbDriver(String dbDriver) {
		SPprobe_DAO.dbDriver = dbDriver;
	}

	public static String getConfiguration_FIle_Name() {
		return Configuration_File_Name;
	}

	public static void setConfiguration_FIle_Name(String configuration_FIle_Name) {
		Configuration_File_Name = configuration_FIle_Name;
	}

	protected static void loadDBproperty() {

		ProbeConfig dbProperty = new ProbeConfig(Configuration_File_Name);
		setDbDriver(dbProperty.getPropertyValue("dbDriver"));
		setDbUrl(dbProperty.getPropertyValue("dbUrl"));
		setDbUserName(dbProperty.getPropertyValue("dbUserName"));
		setDbPassWord(dbProperty.getPropertyValue("dbPassWord"));

	}

	protected SPprobe_DAO() {
		loadDBproperty();

	}

	protected static Connection getConnection() {
		try {
			loadDBproperty();
			Class.forName(dbDriver);
			System.out.println("connection is initiated");
			SPProbe_Logger.logger.info("DATABASE connection is initiated");
			connectionInstance = DriverManager.getConnection(
					SPprobe_DAO.getDbUrl(), SPprobe_DAO.getDbUserName(),
					SPprobe_DAO.getDbPassWord());
			SPProbe_Logger.logger.info("Now DATABASE is connected");
			System.out.println("Database is connected");
			return connectionInstance;

		} catch (ClassNotFoundException | SQLException ex) {
			ex.printStackTrace();
			SPProbe_Logger.logger.error("Database is not connected");
			System.out.println("Database is not connected");

		}
          return connectionInstance;
	}

	@SuppressWarnings("unused")
	public static Connection getConnection(String DB_Driver, String DB_url,
			String DB_userName, String DB_Password) {
		if (connectionInstance == null) {
			try {
				Class.forName(DB_Driver);
				connectionInstance = DriverManager.getConnection(DB_url,
						DB_userName, DB_Password);
				System.out.println("connection is initiated");
				SPProbe_Logger.logger.info("DATABASE is connected ");
				return connectionInstance;
			} catch (ClassNotFoundException | SQLException e) {
				System.out.println("Database is not connected");
				e.printStackTrace();
				return null;
			}
		} else {
			System.out.println("DATABASE is already connected");
			SPProbe_Logger.logger.warn("DATABASE IS ALLREADY CONNECTED");
		}
		return connectionInstance;
	}

	public static void closeDbConnection() {
		try {
			
			if (connectionInstance != null)
				connectionInstance.close();
			

			System.out.println("dao cleaned up");
			SPProbe_Logger.logger.info("DATABASE connection is Closed");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}    

	}
	
	public static boolean closeConnection(Connection conectionObject) throws SQLException
	{
		if(conectionObject!=null)
		{
			conectionObject.close();
			return true;
		}
		else {
			return false;
		}
	}

	/*
	 * // to insert IP msg public void saveIP_MSG(SS7Message_IP msgdata) { try {
	 * // getConnection(); // String // query=
	 * "insert into SS7Message_IP_Table(ipraw ,iprawlen ) values('asjdjasjd',45454)"
	 * ; String query =
	 * "insert into SS7Message_IP_Table(ipraw ,iprawlen ) values('" +
	 * msgdata.getIpRaw() + "', '" + msgdata.getIpRawLength() + "')";
	 * statementInstance = connectionInstance.createStatement(); int result =
	 * statementInstance.executeUpdate(query); if (result != 0) System.out
	 * .println("SS7Message_IP message inserted into DATABASE"); else System.out
	 * .println("Error : SS7Message_IP message not inserted into DATABASE"); }
	 * catch (SQLException ex) { // ex.printStackTrace();
	 * SPProbe_Logger.logger.error("Error in Storing IP message   :" +
	 * ex.getMessage()); } finally { try { if (preparedStatementInstance !=
	 * null) preparedStatementInstance.close(); } catch (SQLException e) { //
	 * TODO Auto-generated catch block e.printStackTrace(); } }
	 * 
	 * }
	 * 
	 * // to insert M2PA Message public void saveM2PA_MSG(SS7Message_M2PA
	 * msgdata) { try {
	 * 
	 * preparedStatementInstance = connectionInstance .prepareStatement(
	 * "insert into SS7Message_M2PA_Table(message_type ,bsn,bib,fsn,fib,li,sio ) values('"
	 * + msgdata.getMessageType() + "','" + msgdata.getBsn() + "','" +
	 * msgdata.getBib() + "','" + msgdata.getFsn() + "','" + msgdata.getFib() +
	 * "','" + msgdata.getLi() + "','" + msgdata.getSio() + "')  "); int result
	 * = preparedStatementInstance.executeUpdate(); if (result != 0) System.out
	 * .println("SS7Message_M2PA message inserted into DATABASE"); else
	 * System.out
	 * .println("Error : SS7Message_M2PA message not inserted into DATABASE"); }
	 * catch (SQLException ex) {
	 * System.out.println("M2PA message is not inserted.");
	 * System.out.println("Check connection.");
	 * SPProbe_Logger.logger.error("Error in Storing M2PA message   :" +
	 * ex.getMessage()); ex.printStackTrace();
	 * 
	 * } finally { try { if (preparedStatementInstance != null)
	 * preparedStatementInstance.close(); } catch (SQLException e) { // TODO
	 * Auto-generated catch block e.printStackTrace(); } }
	 * 
	 * }
	 * 
	 * // to insert M3UA msg public void saveM3UA_MSG(SS7Message_M3UA msgdata) {
	 * try {
	 * 
	 * preparedStatementInstance = connectionInstance .prepareStatement(
	 * "insert into SS7Message_M3UA_Table(m3uaRaw ,m3uaRawLen,opc,dpc,Message_Type,si,ni,mp,sls ) values('"
	 * + msgdata.getM3uaRaw() + "','" + msgdata.getM3uaRawLength() + "','" +
	 * msgdata.getOpc() + "','" + msgdata.getDpc() + "','" +
	 * msgdata.getMessageType() + "','" + msgdata.getSi() + "','" +
	 * msgdata.getNi() + "','" + msgdata.getMp() + "','" + msgdata.getSls() +
	 * "')  "); int result = preparedStatementInstance.executeUpdate(); if
	 * (result != 0) System.out
	 * .println("SS7Message_M3UA message inserted into DATABASE"); else
	 * System.out
	 * .println("Error : SS7Message_M3UA message not inserted into DATABASE"); }
	 * catch (SQLException ex) { ex.printStackTrace();
	 * SPProbe_Logger.logger.error("Error in Storing M3UA message   :" +
	 * ex.getMessage()); } finally { try { if (preparedStatementInstance !=
	 * null) preparedStatementInstance.close(); } catch (SQLException e) { //
	 * TODO Auto-generated catch block e.printStackTrace(); } }
	 * 
	 * }
	 * 
	 * /* public static void main(String[] args) {
	 * 
	 * // TODO Auto-generated method stub
	 * //PropertyConfigurator.configure("Log4j.properties");// set logger
	 * Properties //SPProbe_Logger.logger.setLevel(Level.INFO);// set logger
	 * level
	 * 
	 * //SPProbe_Logger.logger.info(""); /*SS7Message_IP ss7ip=new
	 * SS7Message_IP(); ss7ip.setIpRaw("Msg_Ip"); ss7ip.setIpRawLength(1212);
	 * SS7Message_M2PA ds=new SS7Message_M2PA(); ds.setBib("hvh");
	 * ds.setBsn(11545); ds.setFib("joo"); ds.setFsn(4545); short j=4545;
	 * ds.setLi(j); ds.setMessageType("SS7Message_M2PA"); ds.setSio("skfsf");
	 * 
	 * SPprobe_DAO dao=new SPprobe_DAO(); dao.loadDbProperty();
	 * dao.saveM2PA_MSG(ds); dao.closeDbConnection();
	 * 
	 * }
	 */
}
